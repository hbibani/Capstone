<?php
require "DataBase.php";
$db = new DataBase();


if (isset($_POST['patientnotesid']) && isset($_POST['notes']) && isset($_POST['datetime'])  )
{
    if ($db->dbConnect()) 
    {
        $db->modifyPatientNotes($_POST['patientnotesid'], $_POST['notes'], $_POST['datetime']);
    } 
    else echo "Error: Database connection";
} 
else echo "All fields are required";


?>
