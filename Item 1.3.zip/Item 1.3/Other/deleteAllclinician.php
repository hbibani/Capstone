<?php
require "DataBase.php";
$db = new DataBase();


if (isset($_POST['userid']) && isset($_POST['staffnumber']) ) 
{
    if ($db->dbConnect()) 
    {
        $db->deleteAllRecordOfClinician($_POST['userid'], $_POST['staffnumber']);
    }
    else echo "Error: Database connection";
} else echo "All fields are required";
?>

