<?php
require "DataBase.php";
$db = new DataBase();


if (isset($_POST['rolename']) && isset($_POST['rolepower'])) 
{
    if ($db->dbConnect()) 
    {
        $db->addRoleToDatabase( $_POST['rolename'], $_POST['rolepower']);

    } 
    else echo "Error: Database connection";
} else echo "All fields are required";
?>