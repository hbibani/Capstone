<?php
        require "DataBase.php";
        $db = new DataBase();
        
        if (isset($_POST['patientnotesid'])) 
        {
            if ($db->dbConnect()) 
            {
                $db->deletePatientNotes($_POST['patientnotesid']);
            } 
        }
        else echo "All fields required";
?>
