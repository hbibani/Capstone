<?php
require "DataBase.php";
$db = new DataBase();


if (isset($_POST['username']) && isset($_POST['password']) && isset($_POST['staffnumber']) && isset($_POST['clintype']) ) 
{
    if ($db->dbConnect()) 
    {
        $db->addNewClinician( $_POST['username'], $_POST['password'], $_POST['staffnumber'], $_POST['clintype']);

    } 
    else echo "Error: Database connection";
} else echo "All fields are required";
?>