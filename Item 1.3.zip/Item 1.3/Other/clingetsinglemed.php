<?php
require "DataBase.php";
$db = new DataBase();




if (isset($_POST['medicationstayid'])) 
{
    if ($db->dbConnect()) 
    {
        $stringReturn = $db->getSingleMedForPatient($_POST['medicationstayid']);
       
    } 
    
} 
else echo "All fields are required";


?>
