<?php
require "DataBase.php";
$db = new DataBase();


if (isset($_POST['mrn'])) 
{
    if ($db->dbConnect()) 
    {
        $db->searchPatient( $_POST['mrn']);

    } 
    else echo "Error: Database connection";
} else echo "All fields are required";
?>