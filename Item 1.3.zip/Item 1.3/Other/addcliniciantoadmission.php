<?php
require "DataBase.php";
$db = new DataBase();


if (isset($_POST['admissionid']) && isset($_POST['clinicianid'])) 
{
    if ($db->dbConnect()) 
    {
        $db->addClinToAdmission( $_POST['admissionid'], $_POST['clinicianid']);

    } 
    else echo "Error: Database connection";
} else echo "All fields are required";
?>