<?php
require "DataBase.php";
$db = new DataBase();


if (isset($_POST['username']) && isset($_POST['password']) && isset($_POST['userid']) ) 
{
    if ($db->dbConnect()) 
    {
        $db->updateUsernameAndPassword($_POST['username'], $_POST['password'], $_POST['userid']);
    } 
    else echo "Error: Database connection";
} else echo "All fields are required";
?>


