<?php
require "DataBase.php";
$db = new DataBase();


if (isset($_POST['admissionid']) && isset($_POST['notes']) && isset($_POST['datetime']) )
{
    if ($db->dbConnect()) 
    {
        $db->addNotestoAdmission($_POST['admissionid'], $_POST['notes'], $_POST['datetime'] );
    } 
    else echo "Error: Database connection";
} 
else echo "All fields are required";


?>
