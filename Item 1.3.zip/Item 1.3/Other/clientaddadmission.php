<?php
require "DataBase.php";
$db = new DataBase();


if (isset($_POST['username']) && isset($_POST['paintype']) && isset($_POST['mrn']) && isset($_POST['painregion']) && isset($_POST['datetime']) && isset($_POST['bednumber'])) 
{
    if ($db->dbConnect()) 
    {
        $db->addAdmissionClient($_POST['mrn'], $_POST['username'], $_POST['paintype'], $_POST['painregion'], $_POST['datetime'], $_POST['bednumber']);
    } 
    else echo "Error: Database connection";
} else echo "All fields are required";
?>