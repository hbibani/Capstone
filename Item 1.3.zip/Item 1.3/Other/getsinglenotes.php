<?php
require "DataBase.php";
$db = new DataBase();


if (isset($_POST['patientnotesid'])) 
{
    if ($db->dbConnect()) 
    {
       $db->getSingleNotes($_POST['patientnotesid']);
        
    } 
    else echo "Error: Database connection";
} 
else echo "All fields are required";


?>
