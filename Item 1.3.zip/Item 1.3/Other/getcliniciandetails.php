<?php
require "DataBase.php";
$db = new DataBase();


if (isset($_POST['clinicianid'])) 
{
    if ($db->dbConnect()) 
    {
       $db->getClinicianDetails($_POST['clinicianid']);
        
    } 
    else echo "Error: Database connection";
} 
else echo "All fields are required";


?>
