<?php
require "DataBase.php";
$db = new DataBase();




if (isset($_POST['username']) && isset($_POST['password']) && isset($_POST['token']) )
{
    if ($db->dbConnect()) 
    {
        $stringReturn = $db->logIn($_POST['username'], $_POST['password'], $_POST['token']);
        if($stringReturn == "1" || $stringReturn == "2" || $stringReturn == "3") 
        {
            echo "Role: '" . $stringReturn ."'";
        } 
        else echo $stringReturn;
    } 
    else echo "Error: Database connection";
} 
else echo "All fields are required";


?>
