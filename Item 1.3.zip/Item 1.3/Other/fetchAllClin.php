<?php
require "DataBase.php";
$db = new DataBase();


    if ($db->dbConnect()) 
    {
        $db->fetClinList();
    } 
    else echo "Error: Database connection";

?>