<?php
require "DataBase.php";
$db = new DataBase();


if (isset($_POST['graphid']) )
{
    if ($db->dbConnect())
    {
       $db->getLastValueOfPainForButton($_POST['graphid']);
    }
    else echo "Error: Database connection";
}
else echo "All fields are required";


?>
