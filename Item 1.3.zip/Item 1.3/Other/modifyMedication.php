<?php
require "DataBase.php";
$db = new DataBase();


if (isset($_POST['medicationid']) && isset($_POST['medbrand']) && isset($_POST['medchem']) && isset($_POST['dosage']) && isset($_POST['doseform']) )
{
    if ($db->dbConnect()) 
    {
        $db->modifyMedicationAdmin($_POST['medicationid'], $_POST['medbrand'],$_POST['medchem'], $_POST['dosage'], $_POST['doseform'] );
    } 
    else echo "Error: Database connection";
} 
else echo "All fields are required";


?>
