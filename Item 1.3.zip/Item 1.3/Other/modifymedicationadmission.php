<?php
require "DataBase.php";
$db = new DataBase();


if (isset($_POST['medicationstayid']) && isset($_POST['medicationid']) && isset($_POST['datetime']))
{
    if ($db->dbConnect()) 
    {
        $db->modifyMedicationAdmission($_POST['medicationstayid'], $_POST['medicationid'], $_POST['datetime']);
    } 
    else echo "Error: Database connection";
} 
else echo "All fields are required";

?>