<?php
require "DataBase.php";
$db = new DataBase();


if (isset($_POST['staffnumber'])) 
{
    if ($db->dbConnect()) 
    {
        $db->searchAdmissionStaffNumber($_POST['staffnumber']);

    } 
    else echo "Error: Database connection";
} else echo "All fields are required";
?>

