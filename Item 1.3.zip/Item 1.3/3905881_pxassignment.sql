-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: fdb32.awardspace.net
-- Generation Time: Aug 11, 2021 at 05:33 PM
-- Server version: 5.7.20-log
-- PHP Version: 5.5.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `3905881_pxassignment`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `AdminID` int(11) NOT NULL,
  `UserID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `admission`
--

CREATE TABLE `admission` (
  `AdmissionID` int(11) NOT NULL,
  `PatientID` int(11) NOT NULL,
  `PainType` varchar(20) NOT NULL,
  `PainRegion` varchar(20) NOT NULL,
  `StartTime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `EndTime` datetime DEFAULT NULL,
  `Status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admission`
--

INSERT INTO `admission` (`AdmissionID`, `PatientID`, `PainType`, `PainRegion`, `StartTime`, `EndTime`, `Status`) VALUES
(50, 59, 'Backpain', 'Back', '2021-08-11 21:00:01', NULL, 0),
(51, 60, 'sadas', 'asdas', '2021-08-11 21:27:03', NULL, 0),
(52, 35, 'Throbbing', 'Back', '2021-08-12 01:04:27', NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `clinician`
--

CREATE TABLE `clinician` (
  `ClinicianID` int(11) NOT NULL,
  `UserID` int(11) NOT NULL,
  `StaffNumber` varchar(30) NOT NULL,
  `ClinicianType` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `clinician`
--

INSERT INTO `clinician` (`ClinicianID`, `UserID`, `StaffNumber`, `ClinicianType`) VALUES
(16, 72, '12345', 'Doctor'),
(17, 73, '123456', 'Doctor'),
(20, 104, '123456789', 'Doctor');

-- --------------------------------------------------------

--
-- Table structure for table `clinicianadmission`
--

CREATE TABLE `clinicianadmission` (
  `ClinicianAdmissionID` int(11) NOT NULL,
  `ClinicianID` int(11) NOT NULL,
  `AdmissionID` int(11) NOT NULL,
  `PushNotification` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `clinicianadmission`
--

INSERT INTO `clinicianadmission` (`ClinicianAdmissionID`, `ClinicianID`, `AdmissionID`, `PushNotification`) VALUES
(58, 17, 52, 1),
(59, 20, 52, 1),
(60, 16, 50, 1),
(61, 16, 51, 1);

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `FeedbackID` int(11) NOT NULL,
  `AdmissionID` int(11) NOT NULL,
  `Question1` tinyint(1) NOT NULL,
  `Question2` tinyint(1) NOT NULL,
  `Question3` tinyint(1) NOT NULL,
  `Question4` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`FeedbackID`, `AdmissionID`, `Question1`, `Question2`, `Question3`, `Question4`) VALUES
(16, 50, 0, 1, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `graph`
--

CREATE TABLE `graph` (
  `GraphID` int(11) NOT NULL,
  `AdmissionID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `graph`
--

INSERT INTO `graph` (`GraphID`, `AdmissionID`) VALUES
(58, 50),
(59, 51),
(60, 52);

-- --------------------------------------------------------

--
-- Table structure for table `graphvalue`
--

CREATE TABLE `graphvalue` (
  `GraphValueID` int(11) NOT NULL,
  `GraphID` int(11) NOT NULL,
  `PainScore` int(11) NOT NULL,
  `Time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `graphvalue`
--

INSERT INTO `graphvalue` (`GraphValueID`, `GraphID`, `PainScore`, `Time`) VALUES
(28, 60, 3, '2021-08-11 16:33:31'),
(29, 60, 7, '2021-08-11 16:37:22'),
(30, 60, 10, '2021-08-11 16:37:36'),
(31, 60, 11, '2021-08-11 16:37:53');

-- --------------------------------------------------------

--
-- Table structure for table `medication`
--

CREATE TABLE `medication` (
  `MedicationID` int(11) NOT NULL,
  `MedBrand` varchar(30) NOT NULL,
  `MedChemName` varchar(30) NOT NULL,
  `Dosage` varchar(10) NOT NULL,
  `DoseForm` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `medication`
--

INSERT INTO `medication` (`MedicationID`, `MedBrand`, `MedChemName`, `Dosage`, `DoseForm`) VALUES
(11, 'Panadeine Forte', 'Codeine', '23mg', 'Oral'),
(12, 'Panadeine', 'Codeine', '20mg', 'Oral');

-- --------------------------------------------------------

--
-- Table structure for table `medicationstay`
--

CREATE TABLE `medicationstay` (
  `MedicationStayID` int(11) NOT NULL,
  `MedicationID` int(11) NOT NULL,
  `AdmissionID` int(11) NOT NULL,
  `Time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `patient`
--

CREATE TABLE `patient` (
  `PatientID` int(11) NOT NULL,
  `UserID` int(11) NOT NULL,
  `MRN` varchar(30) NOT NULL,
  `PatientGender` varchar(11) NOT NULL,
  `PatientAge` int(11) NOT NULL,
  `PatientWeight` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `patient`
--

INSERT INTO `patient` (`PatientID`, `UserID`, `MRN`, `PatientGender`, `PatientAge`, `PatientWeight`) VALUES
(35, 83, '12345678', 'Male', 23, 23),
(40, 88, '123456789', 'Female', 25, 24),
(42, 103, '12345678910', 'Male', 24, 25),
(43, 105, '23423423423423', 'Male', 25, 25),
(45, 107, '987654321', 'Male', 24, 23),
(46, 108, '123455621321321', 'Male', 25, 2342),
(47, 109, '789645', 'Male', 25, 244),
(49, 112, '12345623432', 'Male', 23, 23),
(50, 113, '12345632423', 'Male', 25, 244),
(51, 114, ' 1234512345', 'Male', 2455, 232),
(53, 116, '2222', 'Male', 24, 24),
(54, 117, '2322', 'Male', 24, 24),
(55, 118, '23432423', 'Male', 2342, 2342),
(56, 119, '55555', 'Male', 235, 2325),
(59, 123, '7777', 'Male', 25, 255),
(60, 124, '1234567832', 'Male', 25, 25);

-- --------------------------------------------------------

--
-- Table structure for table `patientnotes`
--

CREATE TABLE `patientnotes` (
  `PatientNotesID` int(11) NOT NULL,
  `AdmissionID` int(11) NOT NULL,
  `Notes` varchar(500) NOT NULL,
  `Time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `patientnotes`
--

INSERT INTO `patientnotes` (`PatientNotesID`, `AdmissionID`, `Notes`, `Time`) VALUES
(66, 51, 'heja', '2021-08-12 03:24:51');

-- --------------------------------------------------------

--
-- Table structure for table `role`
--

CREATE TABLE `role` (
  `RoleID` int(11) NOT NULL,
  `RoleName` varchar(20) NOT NULL,
  `RolePower` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `role`
--

INSERT INTO `role` (`RoleID`, `RoleName`, `RolePower`) VALUES
(1, 'Admin', 1),
(2, 'Clinician', 2),
(3, 'Patient', 3);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `UserID` int(11) NOT NULL,
  `RoleID` int(11) NOT NULL,
  `Username` varchar(20) NOT NULL,
  `Password` varchar(80) NOT NULL,
  `Token` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`UserID`, `RoleID`, `Username`, `Password`, `Token`) VALUES
(26, 1, 'admin', 'admin', 'c7JkhQrbRWqgrUcnQgTywB:APA91bGSabM4OT2eyhruFZ4L1W2Wf1fsRjnruvMSWLoTfWkezg7jpkYt5-ewv4znrEJZWunhu49Dkut8Orb0law4Co8mSpiKZHbVKveGpeDPsYP8SKV8MeVzH1sKuG4uqDxtkzLj4cAG'),
(72, 2, 'username2', 'password', 'c7JkhQrbRWqgrUcnQgTywB:APA91bGSabM4OT2eyhruFZ4L1W2Wf1fsRjnruvMSWLoTfWkezg7jpkYt5-ewv4znrEJZWunhu49Dkut8Orb0law4Co8mSpiKZHbVKveGpeDPsYP8SKV8MeVzH1sKuG4uqDxtkzLj4cAG'),
(73, 2, 'username3', 'password', 'c7JkhQrbRWqgrUcnQgTywB:APA91bGSabM4OT2eyhruFZ4L1W2Wf1fsRjnruvMSWLoTfWkezg7jpkYt5-ewv4znrEJZWunhu49Dkut8Orb0law4Co8mSpiKZHbVKveGpeDPsYP8SKV8MeVzH1sKuG4uqDxtkzLj4cAG'),
(83, 3, 'username79', 'password', 'eW2XQytsQKeyFSpbiqm3Ts:APA91bGMFl4ChXJ2QzOdsxLrL9WZjX4D-SNIUmo9_yGAkQZz_mLTlxfOpgRlKuizIQUV-THvXfQGgvLsobsfmkwn1EfD_1JSmPzu3vgIeuO4QNCB-4YGyZEjp0dCJ_9tCrD60ZF7iTJX'),
(88, 3, 'username101', 'password', ''),
(103, 3, 'username11', 'password', ''),
(104, 2, 'username22222', 'password', ''),
(105, 3, 'username112', 'password', ''),
(107, 3, 'username222', 'password', ''),
(108, 3, 'username22323', 'password', ''),
(109, 3, 'username155', 'password', ''),
(112, 3, 'username1555', 'password', ''),
(113, 3, 'aiusdhauisdhas', 'asdasdasd', ''),
(114, 3, 'username21321', 'password', ''),
(116, 3, 'username1110', 'password', ''),
(117, 3, 'username2221', 'password', ''),
(118, 3, 'asdasdas', 'sadasdas', ''),
(119, 3, 'username5555', 'password5', ''),
(123, 3, 'username777', 'password', ''),
(124, 3, 'username12332', 'password', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`AdminID`),
  ADD KEY `fk_to_userid` (`UserID`);

--
-- Indexes for table `admission`
--
ALTER TABLE `admission`
  ADD PRIMARY KEY (`AdmissionID`),
  ADD KEY `fk_to_patientIDadd` (`PatientID`);

--
-- Indexes for table `clinician`
--
ALTER TABLE `clinician`
  ADD PRIMARY KEY (`ClinicianID`),
  ADD UNIQUE KEY `fk_to_useridclin` (`UserID`) USING BTREE,
  ADD UNIQUE KEY `StaffNumber` (`StaffNumber`);

--
-- Indexes for table `clinicianadmission`
--
ALTER TABLE `clinicianadmission`
  ADD PRIMARY KEY (`ClinicianAdmissionID`),
  ADD KEY `fk_to_admissionIDca` (`AdmissionID`),
  ADD KEY `ClinicianID` (`ClinicianID`) USING BTREE;

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`FeedbackID`),
  ADD UNIQUE KEY `AdmissionID` (`AdmissionID`);

--
-- Indexes for table `graph`
--
ALTER TABLE `graph`
  ADD PRIMARY KEY (`GraphID`),
  ADD UNIQUE KEY `AdmissionID` (`AdmissionID`) USING BTREE;

--
-- Indexes for table `graphvalue`
--
ALTER TABLE `graphvalue`
  ADD PRIMARY KEY (`GraphValueID`),
  ADD KEY `fk_to_graphid` (`GraphID`);

--
-- Indexes for table `medication`
--
ALTER TABLE `medication`
  ADD PRIMARY KEY (`MedicationID`);

--
-- Indexes for table `medicationstay`
--
ALTER TABLE `medicationstay`
  ADD PRIMARY KEY (`MedicationStayID`),
  ADD KEY `fk_to_admissionIDms` (`AdmissionID`),
  ADD KEY `fk_to_medicationIDms` (`MedicationID`);

--
-- Indexes for table `patient`
--
ALTER TABLE `patient`
  ADD PRIMARY KEY (`PatientID`),
  ADD UNIQUE KEY `MRN` (`MRN`),
  ADD KEY `fk_to_useridpati` (`UserID`),
  ADD KEY `PatientAge` (`PatientAge`),
  ADD KEY `PatientAge_2` (`PatientAge`),
  ADD KEY `PatientAge_3` (`PatientAge`),
  ADD KEY `PatientAge_4` (`PatientAge`);

--
-- Indexes for table `patientnotes`
--
ALTER TABLE `patientnotes`
  ADD PRIMARY KEY (`PatientNotesID`),
  ADD KEY `AdmissionID` (`AdmissionID`) USING BTREE;

--
-- Indexes for table `role`
--
ALTER TABLE `role`
  ADD PRIMARY KEY (`RoleID`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`UserID`),
  ADD UNIQUE KEY `Username` (`Username`),
  ADD KEY `fk_to_Roleid` (`RoleID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `AdminID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `admission`
--
ALTER TABLE `admission`
  MODIFY `AdmissionID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;
--
-- AUTO_INCREMENT for table `clinician`
--
ALTER TABLE `clinician`
  MODIFY `ClinicianID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
--
-- AUTO_INCREMENT for table `clinicianadmission`
--
ALTER TABLE `clinicianadmission`
  MODIFY `ClinicianAdmissionID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=63;
--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `FeedbackID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `graph`
--
ALTER TABLE `graph`
  MODIFY `GraphID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=61;
--
-- AUTO_INCREMENT for table `graphvalue`
--
ALTER TABLE `graphvalue`
  MODIFY `GraphValueID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;
--
-- AUTO_INCREMENT for table `medication`
--
ALTER TABLE `medication`
  MODIFY `MedicationID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `medicationstay`
--
ALTER TABLE `medicationstay`
  MODIFY `MedicationStayID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=76;
--
-- AUTO_INCREMENT for table `patient`
--
ALTER TABLE `patient`
  MODIFY `PatientID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=61;
--
-- AUTO_INCREMENT for table `patientnotes`
--
ALTER TABLE `patientnotes`
  MODIFY `PatientNotesID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=68;
--
-- AUTO_INCREMENT for table `role`
--
ALTER TABLE `role`
  MODIFY `RoleID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `UserID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=125;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `admin`
--
ALTER TABLE `admin`
  ADD CONSTRAINT `fk_to_userid` FOREIGN KEY (`UserID`) REFERENCES `user` (`UserID`);

--
-- Constraints for table `admission`
--
ALTER TABLE `admission`
  ADD CONSTRAINT `fk_to_patientIDadd` FOREIGN KEY (`PatientID`) REFERENCES `patient` (`PatientID`);

--
-- Constraints for table `clinician`
--
ALTER TABLE `clinician`
  ADD CONSTRAINT `fk_to_useridclin` FOREIGN KEY (`UserID`) REFERENCES `user` (`UserID`);

--
-- Constraints for table `clinicianadmission`
--
ALTER TABLE `clinicianadmission`
  ADD CONSTRAINT `clinicianadmission_ibfk_1` FOREIGN KEY (`ClinicianID`) REFERENCES `clinician` (`ClinicianID`),
  ADD CONSTRAINT `fk_to_admissionIDca` FOREIGN KEY (`AdmissionID`) REFERENCES `admission` (`AdmissionID`);

--
-- Constraints for table `feedback`
--
ALTER TABLE `feedback`
  ADD CONSTRAINT `fk_to_admissionIDfb` FOREIGN KEY (`AdmissionID`) REFERENCES `admission` (`AdmissionID`);

--
-- Constraints for table `graph`
--
ALTER TABLE `graph`
  ADD CONSTRAINT `graph_ibfk_1` FOREIGN KEY (`AdmissionID`) REFERENCES `admission` (`AdmissionID`);

--
-- Constraints for table `graphvalue`
--
ALTER TABLE `graphvalue`
  ADD CONSTRAINT `fk_to_graphid` FOREIGN KEY (`GraphID`) REFERENCES `graph` (`GraphID`);

--
-- Constraints for table `medicationstay`
--
ALTER TABLE `medicationstay`
  ADD CONSTRAINT `fk_to_admissionIDms` FOREIGN KEY (`AdmissionID`) REFERENCES `admission` (`AdmissionID`),
  ADD CONSTRAINT `fk_to_medication1IDms` FOREIGN KEY (`MedicationID`) REFERENCES `medication` (`MedicationID`),
  ADD CONSTRAINT `fk_to_medicationIDms` FOREIGN KEY (`MedicationID`) REFERENCES `medication` (`MedicationID`);

--
-- Constraints for table `patient`
--
ALTER TABLE `patient`
  ADD CONSTRAINT `fk_to_useridpati` FOREIGN KEY (`UserID`) REFERENCES `user` (`UserID`);

--
-- Constraints for table `patientnotes`
--
ALTER TABLE `patientnotes`
  ADD CONSTRAINT `fk_to_admissionIDpn` FOREIGN KEY (`AdmissionID`) REFERENCES `admission` (`AdmissionID`);

--
-- Constraints for table `user`
--
ALTER TABLE `user`
  ADD CONSTRAINT `fk_to_Roleid` FOREIGN KEY (`RoleID`) REFERENCES `role` (`RoleID`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
