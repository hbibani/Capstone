-- phpMyAdmin SQL Dump
-- version 4.9.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Aug 29, 2021 at 06:04 AM
-- Server version: 10.3.16-MariaDB
-- PHP Version: 7.3.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `id17433253_ps2130`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `AdminID` int(11) NOT NULL,
  `UserID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `admission`
--

CREATE TABLE `admission` (
  `AdmissionID` int(11) NOT NULL,
  `PatientID` int(11) NOT NULL,
  `PainType` varchar(20) NOT NULL,
  `PainRegion` varchar(20) NOT NULL,
  `StartTime` datetime NOT NULL DEFAULT current_timestamp(),
  `EndTime` datetime DEFAULT NULL,
  `Status` tinyint(1) NOT NULL,
  `Bed` varchar(11) DEFAULT NULL,
  `Concerned` int(2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admission`
--

INSERT INTO `admission` (`AdmissionID`, `PatientID`, `PainType`, `PainRegion`, `StartTime`, `EndTime`, `Status`, `Bed`, `Concerned`) VALUES
(58, 77, 'back', 'back', '2021-08-15 22:17:39', NULL, 0, '29', 1),
(62, 77, 'Away', 'Hands', '2021-08-22 04:33:05', NULL, 0, '79', 0),
(63, 87, 'Throbbing', 'Back', '2021-08-25 04:21:20', NULL, 0, '23', 0),
(64, 88, 'Throbbing', 'back', '2021-08-25 11:13:12', NULL, 1, '44', NULL),
(65, 89, 'Throbbing.', 'Back.', '2021-08-25 11:52:18', NULL, 1, '65', 1);

-- --------------------------------------------------------

--
-- Table structure for table `clinician`
--

CREATE TABLE `clinician` (
  `ClinicianID` int(11) NOT NULL,
  `UserID` int(11) NOT NULL,
  `StaffNumber` varchar(30) NOT NULL,
  `ClinicianType` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `clinician`
--

INSERT INTO `clinician` (`ClinicianID`, `UserID`, `StaffNumber`, `ClinicianType`) VALUES
(29, 146, '12345', 'Nurse'),
(32, 163, '987654321', 'Doctor');

-- --------------------------------------------------------

--
-- Table structure for table `clinicianadmission`
--

CREATE TABLE `clinicianadmission` (
  `ClinicianAdmissionID` int(11) NOT NULL,
  `ClinicianID` int(11) NOT NULL,
  `AdmissionID` int(11) NOT NULL,
  `PushNotification` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `clinicianadmission`
--

INSERT INTO `clinicianadmission` (`ClinicianAdmissionID`, `ClinicianID`, `AdmissionID`, `PushNotification`) VALUES
(84, 29, 63, 1);

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `FeedbackID` int(11) NOT NULL,
  `AdmissionID` int(11) NOT NULL,
  `Question1` tinyint(1) NOT NULL,
  `Question2` tinyint(1) NOT NULL,
  `Question3` tinyint(1) NOT NULL,
  `Question4` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`FeedbackID`, `AdmissionID`, `Question1`, `Question2`, `Question3`, `Question4`) VALUES
(20, 58, 1, 1, 1, 0),
(21, 62, 1, 1, 1, 0),
(22, 63, 1, 1, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `graph`
--

CREATE TABLE `graph` (
  `GraphID` int(11) NOT NULL,
  `AdmissionID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `graph`
--

INSERT INTO `graph` (`GraphID`, `AdmissionID`) VALUES
(66, 58),
(70, 62),
(71, 63),
(72, 64),
(73, 65);

-- --------------------------------------------------------

--
-- Table structure for table `graphvalue`
--

CREATE TABLE `graphvalue` (
  `GraphValueID` int(11) NOT NULL,
  `GraphID` int(11) NOT NULL,
  `PainScore` int(11) NOT NULL,
  `Time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `graphvalue`
--

INSERT INTO `graphvalue` (`GraphValueID`, `GraphID`, `PainScore`, `Time`) VALUES
(299, 66, 11, '2021-08-17 12:18:43'),
(300, 66, 0, '2021-08-17 12:19:58'),
(301, 66, 11, '2021-08-17 12:21:06'),
(302, 66, 9, '2021-08-18 04:03:46'),
(303, 70, 3, '2021-08-22 17:17:05'),
(304, 70, 5, '2021-08-22 17:19:39'),
(305, 70, 7, '2021-08-22 17:22:12'),
(306, 70, 3, '2021-08-22 17:30:01'),
(307, 70, 5, '2021-08-22 17:32:02'),
(308, 70, 3, '2021-08-22 22:08:54'),
(309, 70, 10, '2021-08-22 22:15:07'),
(310, 70, 11, '2021-08-22 22:37:42'),
(311, 70, 7, '2021-08-22 22:40:40'),
(312, 70, 11, '2021-08-22 22:42:04'),
(313, 70, 3, '2021-08-24 10:49:39'),
(314, 70, 3, '2021-08-24 10:49:46'),
(315, 70, 10, '2021-08-24 10:51:00'),
(316, 70, 10, '2021-08-24 10:54:20'),
(317, 70, 3, '2021-08-24 11:46:09'),
(318, 70, 3, '2021-08-24 11:47:21'),
(319, 70, 11, '2021-08-24 13:32:59'),
(320, 70, 11, '2021-08-24 13:39:24'),
(321, 70, 0, '2021-08-24 13:39:52'),
(322, 70, 11, '2021-08-24 13:47:42'),
(323, 70, 11, '2021-08-24 13:48:09'),
(324, 70, 11, '2021-08-24 13:48:14'),
(325, 70, 0, '2021-08-24 13:48:18'),
(326, 70, 11, '2021-08-24 14:03:18'),
(327, 70, 11, '2021-08-24 14:06:33'),
(328, 70, 1, '2021-08-24 14:16:47'),
(329, 70, 1, '2021-08-24 14:16:48'),
(330, 70, 0, '2021-08-24 14:16:52'),
(331, 70, 11, '2021-08-24 14:23:36'),
(332, 70, 1, '2021-08-24 14:24:16'),
(333, 70, 11, '2021-08-24 14:24:20'),
(334, 70, 2, '2021-08-24 14:28:16'),
(335, 70, 10, '2021-08-24 16:38:07'),
(336, 70, 1, '2021-08-24 17:34:34'),
(337, 70, 11, '2021-08-24 17:51:51'),
(338, 70, 1, '2021-08-24 17:51:59'),
(339, 70, 8, '2021-08-24 17:54:03'),
(340, 70, 1, '2021-08-24 18:19:36'),
(341, 71, 3, '2021-08-24 18:57:52'),
(342, 70, 11, '2021-08-24 19:01:33'),
(343, 71, 10, '2021-08-25 01:09:12'),
(344, 70, 9, '2021-08-25 01:14:10'),
(345, 70, 0, '2021-08-25 01:14:16'),
(346, 71, 9, '2021-08-25 01:49:00'),
(347, 71, 0, '2021-08-25 01:49:04'),
(348, 73, 9, '2021-08-25 01:53:06');

-- --------------------------------------------------------

--
-- Table structure for table `medication`
--

CREATE TABLE `medication` (
  `MedicationID` int(11) NOT NULL,
  `MedBrand` varchar(30) NOT NULL,
  `MedChemName` varchar(30) NOT NULL,
  `Dosage` varchar(10) NOT NULL,
  `DoseForm` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `medication`
--

INSERT INTO `medication` (`MedicationID`, `MedBrand`, `MedChemName`, `Dosage`, `DoseForm`) VALUES
(25, 'Panadeine', 'Morphine', '24mg', 'Injection'),
(26, 'Panadeine', 'Codeine', '200mg', 'Oral'),
(27, 'Morphine', 'Morphine', '200mg', 'Oral');

-- --------------------------------------------------------

--
-- Table structure for table `medicationstay`
--

CREATE TABLE `medicationstay` (
  `MedicationStayID` int(11) NOT NULL,
  `MedicationID` int(11) NOT NULL,
  `AdmissionID` int(11) NOT NULL,
  `Time` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `medicationstay`
--

INSERT INTO `medicationstay` (`MedicationStayID`, `MedicationID`, `AdmissionID`, `Time`) VALUES
(13, 27, 58, '2021-08-21 05:42:15'),
(23, 25, 62, '2021-08-24 20:58:47'),
(24, 26, 62, '2021-08-03 03:34:47'),
(25, 27, 62, '2021-08-25 03:35:10');

-- --------------------------------------------------------

--
-- Table structure for table `patient`
--

CREATE TABLE `patient` (
  `PatientID` int(11) NOT NULL,
  `UserID` int(11) NOT NULL,
  `MRN` varchar(30) NOT NULL,
  `PatientGender` varchar(11) NOT NULL,
  `PatientAge` int(11) NOT NULL,
  `PatientWeight` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `patient`
--

INSERT INTO `patient` (`PatientID`, `UserID`, `MRN`, `PatientGender`, `PatientAge`, `PatientWeight`) VALUES
(77, 148, '12345', 'Male', 2557, 3356),
(81, 154, '98765', 'Male', 24, 24),
(82, 155, '098765', 'Male', 25, 32),
(83, 156, '876876', 'Female', 14, 123),
(84, 157, '987654321', 'Male', 24, 255),
(87, 160, '123456789', 'Male', 25, 25),
(88, 161, '543216', 'Male', 232, 32),
(89, 162, '654321', 'Male', 23, 42);

-- --------------------------------------------------------

--
-- Table structure for table `patientnotes`
--

CREATE TABLE `patientnotes` (
  `PatientNotesID` int(11) NOT NULL,
  `AdmissionID` int(11) NOT NULL,
  `Notes` varchar(500) NOT NULL,
  `Time` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `patientnotes`
--

INSERT INTO `patientnotes` (`PatientNotesID`, `AdmissionID`, `Notes`, `Time`) VALUES
(8, 58, 'Test.', '2021-08-21 22:12:52'),
(9, 58, 'Hello Heja good job.', '2021-08-21 23:31:56'),
(10, 58, 'What about another one for the boys.', '2021-08-21 23:32:11'),
(13, 62, 'Heja tested it again.', '2021-08-22 04:58:12'),
(14, 62, 'This application looks really good, good job.', '2021-08-22 04:58:26'),
(16, 62, 'What is the string was long as duck and you couldn\'t do anything but screenshot the damage, but whatever floats their boats. I\'ll add even more just to see what happens.', '2021-08-23 04:01:16'),
(17, 62, 'Hello, Heja is testing the application and it seems to becoming together nicely.', '2021-08-25 03:49:24'),
(19, 63, 'Hello, showing this to the guys. Testing.', '2021-08-25 11:49:42');

-- --------------------------------------------------------

--
-- Table structure for table `role`
--

CREATE TABLE `role` (
  `RoleID` int(11) NOT NULL,
  `RoleName` varchar(20) NOT NULL,
  `RolePower` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `role`
--

INSERT INTO `role` (`RoleID`, `RoleName`, `RolePower`) VALUES
(1, 'Admin', 1),
(2, 'Clinician', 2),
(3, 'Patient', 3);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `UserID` int(11) NOT NULL,
  `RoleID` int(11) NOT NULL,
  `Username` varchar(20) NOT NULL,
  `Password` varchar(80) NOT NULL,
  `Token` varchar(500) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`UserID`, `RoleID`, `Username`, `Password`, `Token`) VALUES
(26, 1, 'admin', 'admin', 'c7JkhQrbRWqgrUcnQgTywB:APA91bGSabM4OT2eyhruFZ4L1W2Wf1fsRjnruvMSWLoTfWkezg7jpkYt5-ewv4znrEJZWunhu49Dkut8Orb0law4Co8mSpiKZHbVKveGpeDPsYP8SKV8MeVzH1sKuG4uqDxtkzLj4cAG'),
(146, 2, 'clinician', 'password', 'cncrlhTADuaBBjwjWHVolp:APA91bE80Y6K4PPp8IT4LMBT6L1bwRYo951QUi_TFRWPevi1JAbvwtU4L6xLi9We2ek1rgxh1cM4X-LioRti0K9YncZKMNlsT6r7TRHRp45K7RD-itA47ttGXVhBuRTvgmh_Fi44pDTB'),
(148, 3, 'patient1', 'patient1', 'c7JkhQrbRWqgrUcnQgTywB:APA91bGSabM4OT2eyhruFZ4L1W2Wf1fsRjnruvMSWLoTfWkezg7jpkYt5-ewv4znrEJZWunhu49Dkut8Orb0law4Co8mSpiKZHbVKveGpeDPsYP8SKV8MeVzH1sKuG4uqDxtkzLj4cAG'),
(154, 3, 'patient2', 'password', NULL),
(155, 3, 'usernametest', 'password', NULL),
(156, 3, 'username2312', 'password', NULL),
(157, 3, 'testuser', 'password', NULL),
(160, 3, 'patient3', 'patient3', 'c7JkhQrbRWqgrUcnQgTywB:APA91bGSabM4OT2eyhruFZ4L1W2Wf1fsRjnruvMSWLoTfWkezg7jpkYt5-ewv4znrEJZWunhu49Dkut8Orb0law4Co8mSpiKZHbVKveGpeDPsYP8SKV8MeVzH1sKuG4uqDxtkzLj4cAG'),
(161, 3, 'username2321', 'password1', NULL),
(162, 3, 'patient6', 'patient6', 'c7JkhQrbRWqgrUcnQgTywB:APA91bGSabM4OT2eyhruFZ4L1W2Wf1fsRjnruvMSWLoTfWkezg7jpkYt5-ewv4znrEJZWunhu49Dkut8Orb0law4Co8mSpiKZHbVKveGpeDPsYP8SKV8MeVzH1sKuG4uqDxtkzLj4cAG'),
(163, 2, 'clinician2', 'password', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`AdminID`),
  ADD KEY `fk_to_userid` (`UserID`);

--
-- Indexes for table `admission`
--
ALTER TABLE `admission`
  ADD PRIMARY KEY (`AdmissionID`),
  ADD KEY `fk_to_patientIDadd` (`PatientID`);

--
-- Indexes for table `clinician`
--
ALTER TABLE `clinician`
  ADD PRIMARY KEY (`ClinicianID`),
  ADD UNIQUE KEY `fk_to_useridclin` (`UserID`) USING BTREE,
  ADD UNIQUE KEY `StaffNumber` (`StaffNumber`);

--
-- Indexes for table `clinicianadmission`
--
ALTER TABLE `clinicianadmission`
  ADD PRIMARY KEY (`ClinicianAdmissionID`),
  ADD KEY `fk_to_admissionIDca` (`AdmissionID`),
  ADD KEY `ClinicianID` (`ClinicianID`) USING BTREE;

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`FeedbackID`),
  ADD UNIQUE KEY `AdmissionID` (`AdmissionID`);

--
-- Indexes for table `graph`
--
ALTER TABLE `graph`
  ADD PRIMARY KEY (`GraphID`),
  ADD UNIQUE KEY `AdmissionID` (`AdmissionID`) USING BTREE;

--
-- Indexes for table `graphvalue`
--
ALTER TABLE `graphvalue`
  ADD PRIMARY KEY (`GraphValueID`),
  ADD KEY `fk_to_graphid` (`GraphID`);

--
-- Indexes for table `medication`
--
ALTER TABLE `medication`
  ADD PRIMARY KEY (`MedicationID`);

--
-- Indexes for table `medicationstay`
--
ALTER TABLE `medicationstay`
  ADD PRIMARY KEY (`MedicationStayID`),
  ADD KEY `fk_to_admissionIDms` (`AdmissionID`),
  ADD KEY `fk_to_medicationIDms` (`MedicationID`);

--
-- Indexes for table `patient`
--
ALTER TABLE `patient`
  ADD PRIMARY KEY (`PatientID`),
  ADD UNIQUE KEY `MRN` (`MRN`),
  ADD KEY `fk_to_useridpati` (`UserID`);

--
-- Indexes for table `patientnotes`
--
ALTER TABLE `patientnotes`
  ADD PRIMARY KEY (`PatientNotesID`),
  ADD KEY `AdmissionID` (`AdmissionID`) USING BTREE;

--
-- Indexes for table `role`
--
ALTER TABLE `role`
  ADD PRIMARY KEY (`RoleID`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`UserID`),
  ADD UNIQUE KEY `Username` (`Username`),
  ADD KEY `fk_to_Roleid` (`RoleID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `AdminID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `admission`
--
ALTER TABLE `admission`
  MODIFY `AdmissionID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=66;

--
-- AUTO_INCREMENT for table `clinician`
--
ALTER TABLE `clinician`
  MODIFY `ClinicianID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `clinicianadmission`
--
ALTER TABLE `clinicianadmission`
  MODIFY `ClinicianAdmissionID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=85;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `FeedbackID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `graph`
--
ALTER TABLE `graph`
  MODIFY `GraphID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=74;

--
-- AUTO_INCREMENT for table `graphvalue`
--
ALTER TABLE `graphvalue`
  MODIFY `GraphValueID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=349;

--
-- AUTO_INCREMENT for table `medication`
--
ALTER TABLE `medication`
  MODIFY `MedicationID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `medicationstay`
--
ALTER TABLE `medicationstay`
  MODIFY `MedicationStayID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `patient`
--
ALTER TABLE `patient`
  MODIFY `PatientID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=90;

--
-- AUTO_INCREMENT for table `patientnotes`
--
ALTER TABLE `patientnotes`
  MODIFY `PatientNotesID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `role`
--
ALTER TABLE `role`
  MODIFY `RoleID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `UserID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=165;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `admin`
--
ALTER TABLE `admin`
  ADD CONSTRAINT `admin_ibfk_1` FOREIGN KEY (`UserID`) REFERENCES `user` (`UserID`);

--
-- Constraints for table `admission`
--
ALTER TABLE `admission`
  ADD CONSTRAINT `admission_ibfk_1` FOREIGN KEY (`PatientID`) REFERENCES `patient` (`PatientID`);

--
-- Constraints for table `clinician`
--
ALTER TABLE `clinician`
  ADD CONSTRAINT `clinician_ibfk_1` FOREIGN KEY (`UserID`) REFERENCES `user` (`UserID`);

--
-- Constraints for table `clinicianadmission`
--
ALTER TABLE `clinicianadmission`
  ADD CONSTRAINT `clinicianadmission_ibfk_1` FOREIGN KEY (`AdmissionID`) REFERENCES `admission` (`AdmissionID`),
  ADD CONSTRAINT `clinicianadmission_ibfk_2` FOREIGN KEY (`ClinicianID`) REFERENCES `clinician` (`ClinicianID`);

--
-- Constraints for table `feedback`
--
ALTER TABLE `feedback`
  ADD CONSTRAINT `feedback_ibfk_1` FOREIGN KEY (`AdmissionID`) REFERENCES `admission` (`AdmissionID`);

--
-- Constraints for table `graph`
--
ALTER TABLE `graph`
  ADD CONSTRAINT `graph_ibfk_1` FOREIGN KEY (`AdmissionID`) REFERENCES `admission` (`AdmissionID`);

--
-- Constraints for table `graphvalue`
--
ALTER TABLE `graphvalue`
  ADD CONSTRAINT `graphvalue_ibfk_1` FOREIGN KEY (`GraphID`) REFERENCES `graph` (`GraphID`);

--
-- Constraints for table `medicationstay`
--
ALTER TABLE `medicationstay`
  ADD CONSTRAINT `medicationstay_ibfk_1` FOREIGN KEY (`AdmissionID`) REFERENCES `admission` (`AdmissionID`),
  ADD CONSTRAINT `medicationstay_ibfk_2` FOREIGN KEY (`MedicationID`) REFERENCES `medication` (`MedicationID`);

--
-- Constraints for table `patient`
--
ALTER TABLE `patient`
  ADD CONSTRAINT `fk_to_useridpati` FOREIGN KEY (`UserID`) REFERENCES `user` (`UserID`);

--
-- Constraints for table `patientnotes`
--
ALTER TABLE `patientnotes`
  ADD CONSTRAINT `patientnotes_ibfk_1` FOREIGN KEY (`AdmissionID`) REFERENCES `admission` (`AdmissionID`);

--
-- Constraints for table `user`
--
ALTER TABLE `user`
  ADD CONSTRAINT `user_ibfk_1` FOREIGN KEY (`RoleID`) REFERENCES `role` (`RoleID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
