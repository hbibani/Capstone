<?php
require "DataBase.php";
$db = new DataBase();


if (isset($_POST['userid']) && isset($_POST['patientid'] )) 
{
    if ($db->dbConnect()) 
    {
        $db->deletePatientAndUserSingle($_POST['userid'], $_POST['patientid']);
    }
    else echo "Error: Database connection";
} else echo "All fields are required";
?>

