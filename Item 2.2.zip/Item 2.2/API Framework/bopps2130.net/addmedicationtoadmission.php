<?php
require "DataBase.php";
$db = new DataBase();


if (isset($_POST['admissionid']) && isset($_POST['medicationid']) && isset($_POST['datetime']) && isset($_POST['doseamount']) ) 
{
    if ($db->dbConnect()) 
    {
        $db->addMedToAdmission( $_POST['admissionid'], $_POST['medicationid'], $_POST['datetime'] , $_POST['doseamount'] );

    } 
    else echo "Error: Database connection";
} else echo "All fields are required";
?>