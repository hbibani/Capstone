<?php
require "DataBase.php";
$db = new DataBase();


if (isset($_POST['admissionid'])) 
{
    if ($db->dbConnect()) 
    {
        $stringReturn = $db->getAdmissionNotesList($_POST['admissionid']);
        echo $stringReturn;
    } 
    else echo "Error: Database connection";
} 
else echo "All fields are required";


?>
