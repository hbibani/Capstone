<?php
require "DataBase.php";
$db = new DataBase();


if (isset($_POST['weight']) && isset($_POST['age']) && isset($_POST['gender']) && isset($_POST['mrn']) && isset($_POST['username']) && isset($_POST['password'])) 
{
    if ($db->dbConnect()) 
    {
        $db->signUp($_POST['mrn'], $_POST['gender'], $_POST['age'], $_POST['weight'], $_POST['username'], $_POST['password']);
    } 
    else echo "Error: Database connection";
} else echo "All fields are required";
?>
