<?php
require "DataBase.php";
$db = new DataBase();


if (isset($_POST['userid']) && isset($_POST['mrn']) && isset($_POST['gender']) && isset($_POST['weight']) && isset($_POST['age']) ) 
{
    if ($db->dbConnect()) 
    {
        $db->updatePatientInfo($_POST['userid'], $_POST['mrn'], $_POST['gender'], $_POST['weight'], $_POST['age']);
    } 
    else echo "Error: Database connection";
} else echo "All fields are required";
?>


