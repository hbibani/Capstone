<?php
require "DataBase.php";
$db = new DataBase();


if (isset( $_POST['admissionid'] ) && isset( $_POST['painregion'] ) && isset( $_POST['paintype'] ) ) 
{
    if ($db->dbConnect()) 
    {
        $db->modifyPainAdmission($_POST['admissionid'], $_POST['painregion'],  $_POST['paintype']  );
    } 
    else echo "Error: Database connection";
} else echo "All fields are required";
?>
