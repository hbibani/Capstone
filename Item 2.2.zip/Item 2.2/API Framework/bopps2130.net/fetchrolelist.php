<?php
require "DataBase.php";
$db = new DataBase();

if ($db->dbConnect()) 
{
        $db->getRoleList();

} 
else echo "Error: Database connection";

?>