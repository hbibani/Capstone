<?php
require "DataBase.php";
$db = new DataBase();


if (isset( $_POST['admissionid'] ) && isset( $_POST['bednumber'] ) ) 
{
    if ($db->dbConnect()) 
    {
        $db->modifyBed($_POST['admissionid'], $_POST['bednumber'] );
    } 
    else echo "Error: Database connection";
} else echo "All fields are required";
?>
