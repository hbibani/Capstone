<?php
require "DataBaseConfig.php";

class DataBase

{
    public $connect;
    public $data;
    private $sql;
    protected $servername;
    protected $username;
    protected $password;
    protected $databasename;

    public function __construct()
    {
        $this->connect = null;
        $this->data = null;
        $this->sql = null;
        $dbc = new DataBaseConfig();
        $this->servername = $dbc->servername;
        $this->username = $dbc->username;
        $this->password = $dbc->password;
        $this->databasename = $dbc->databasename;
    }

    function dbConnect()
    {
        $this->connect = mysqli_connect($this->servername, $this->username, $this->password, $this->databasename);
        return $this->connect;
    }

    function prepareData($data)
    {
        return mysqli_real_escape_string($this->connect, stripslashes(htmlspecialchars($data)));
    }

    function logIn($username, $password, $token)
    {
        $username = $this->prepareData($username);
        $password = $this->prepareData($password);
        $this->sql = "select role.RolePower, user.Username, user.Password FROM user join role on role.RoleID = user.RoleID where user.Username = '" . $username . "' ";
        $result = mysqli_query($this->connect, $this->sql);
        $row = mysqli_fetch_assoc($result);

        if (mysqli_num_rows($result) != 0) {
            $dbusername = $row['Username'];
            $dbpassword = $row['Password'];
            $role = $row['RolePower'];
            $role = strval($role);

            if ($dbusername == $username && $password == $dbpassword) {
                $login = $role;
                $this->sql = "UPDATE user SET Token = '" . $token . "' where user.Username = '" . $username . "' ";
                $result = mysqli_query($this->connect, $this->sql);

            } else $login = "false";


        } else $login = "false";

        return $login;

    }


    function signUp($mrn, $gender, $age, $weight, $username, $password)
    {
        $mrn = $this->prepareData($mrn);
        $gender = $this->prepareData($gender);
        $age = $this->prepareData($age);
        $weight = $this->prepareData($weight);
        $username = $this->prepareData($username);
        $password = $this->prepareData($password);
        $user;
        $this->sql = "select * from patient where MRN = '" . $mrn . "'";
        $result = mysqli_query($this->connect, $this->sql);
        $row = mysqli_fetch_assoc($result);
        if (mysqli_num_rows($result) != 0) {
            echo "search mrn";
            return false;
        }

        $this->sql = "select * from user where Username = '" . $username . "'";
        $result = mysqli_query($this->connect, $this->sql);
        $row = mysqli_fetch_assoc($result);
        if (mysqli_num_rows($result) != 0) {
            echo "search user";
            return false;
        }


        $this->sql = "INSERT INTO user (UserID, RoleID, Username, Password, Token) VALUES (NULL, '3', '" . $username . "', '" . $password . "', NULL)";
        if (mysqli_query($this->connect, $this->sql)) {

        } else {
            echo "user database";
            return false;
        }

        $this->sql = "select * from user where Username = '" . $username . "'";
        $result = mysqli_query($this->connect, $this->sql);
        $row = mysqli_fetch_assoc($result);
        if (mysqli_num_rows($result) != 0) {

            $user = $row['UserID'];

        } else {
            echo "get userid";
            return false;
        }


        $this->sql = "INSERT INTO patient (PatientID, UserID, MRN,PatientGender, PatientAge, PatientWeight) VALUES (NULL , '" . $user . "','" . $mrn . "','" . $gender . "','" . $age . "','" . $weight . "')";

        if (mysqli_query($this->connect, $this->sql)) {
            echo "Sign Up Success";
            return true;
        } else echo "insert patient";
    }


    function addAdmissionClient($mrn, $paintype, $painregion, $datetime, $bednumber, $timer)
    {
        $mrn = $this->prepareData($mrn);
        $paintype = $this->prepareData($paintype);
        $painregion = $this->prepareData($painregion);
        $datetime = $this->prepareData($datetime);
        $patientID;

        //get Patient ID
        $this->sql = "select * from patient where mrn = '" . $mrn . "'";
        $result = mysqli_query($this->connect, $this->sql);
        $row = mysqli_fetch_assoc($result);

        if (mysqli_num_rows($result) != 0) {
            $patientID = $row['PatientID'];

        } else {
            echo "patientid";
            return false;
        }


        //return $patientID;
        //check if already admitted
        $this->sql = "select * from admission where PatientID = '" . $patientID . "' AND Status = 1";
        $result = mysqli_query($this->connect, $this->sql);
        $row = mysqli_fetch_assoc($result);

        if (mysqli_num_rows($result) > 0) {
            echo "Already admitted.";
            return false;
        }

        //create admission
        $this->sql = "INSERT INTO admission (AdmissionID,PatientID, PainType, PainRegion, StartTime, EndTime, Status, Bed, PainTimer) VALUES (NULL,'" . $patientID . "', '" . $paintype . "', '" . $painregion . "', '" . $datetime . "' , NULL, 1, '" . $bednumber . "', '" . $timer . "')";
        if (mysqli_query($this->connect, $this->sql)) {

        } else {
            echo "Insert Admission error.";
            return false;
        }


        //create graph
        $this->sql = "select * from admission where PatientID = '" . $patientID . "' AND Status = 1";
        $result = mysqli_query($this->connect, $this->sql);
        $row = mysqli_fetch_assoc($result);

        if (mysqli_num_rows($result) != 0) {
            $admissionID = $row['AdmissionID'];
        } else {
            echo "No admissions with active status.";
            return false;
        }


        $this->sql = "INSERT INTO graph (GraphID ,AdmissionID) VALUES ( DEFAULT, '" . $admissionID . "')";

        if (mysqli_query($this->connect, $this->sql)) {
            echo "Success";
        } else echo "Problem creating graph.";

    }

    function retActivePatients()
    {

        $this->sql = "SELECT admission.AdmissionID, admission.PainType, admission.PainRegion , admission.Bed, admission.Concerned, admission.Status,patient.mrn, patient.PatientAge, patient.PatientGender, patient.PatientWeight, admission.Concerned, admission.StartTime, admission.EndTime, graph.GraphID FROM admission join graph on admission.AdmissionID = graph.AdmissionID join patient on admission.PatientID = patient.PatientID WHERE admission.Status = 1";
        $result = mysqli_query($this->connect, $this->sql);

        if (mysqli_num_rows($result) != 0) {

            $myArray = array();
            while ($row = mysqli_fetch_assoc($result)) {
                $myArray[] = $row;

            }

            echo json_encode($myArray);

        } else echo "No active patients.";

    }


    function getPatientMedList($admissionid)
    {
        $admissionid = $this->prepareData($admissionid);
        $this->sql = "SELECT medicationstay.MedicationStayID, admission.AdmissionID, patient.mrn, medication.MedicationID ,medication.MedChemName, medication.MedBrand, medication.Dosage, medication.DoseForm, medicationstay.Time, medicationstay.Amount FROM medicationstay join medication on medicationstay.MedicationID = medication.MedicationID join admission on medicationstay.AdmissionID = admission.AdmissionID join patient on admission.PatientID = patient.PatientID WHERE admission.AdmissionID = '" . $admissionid . "'";
        $result = mysqli_query($this->connect, $this->sql);
        if (mysqli_num_rows($result) != 0) {

            $myArray = array();
            while ($row = mysqli_fetch_assoc($result)) {
                $myArray[] = $row;
            }

            echo json_encode($myArray);

        } else return "Not";

    }


    function getSingleMedForPatient($medicationstayid)
    {
        $medicationstayid = $this->prepareData($medicationstayid);
        $this->sql = "SELECT medicationstay.MedicationStayID, medicationstay.Amount, medicationstay.Time, medication.MedBrand, medication.MedChemName, medication.Dosage, medication.DoseForm FROM medicationstay join medication on medicationstay.MedicationID = medication.MedicationID WHERE medicationstay.MedicationStayID = '" . $medicationstayid . "'";

        $result = mysqli_query($this->connect, $this->sql);
        $row = mysqli_fetch_assoc($result);

        if (mysqli_num_rows($result) != 0) {

            $myArray = array();
            $myArray[] = $row;
            echo json_encode($myArray);
        } else echo "None";

    }


    function delMedAdmission($medicationstayid)
    {
        $medicationstayid = $this->prepareData($medicationstayid);
        $this->sql = "DELETE FROM medicationstay WHERE medicationstay.MedicationStayID = '" . $medicationstayid . "'";

        $result = mysqli_query($this->connect, $this->sql);
        if ($result === true) {
            echo "Deleted";
        } else echo "None";


    }


    function getAdmissionNotesList($admissionid)
    {
        $admissionid = $this->prepareData($admissionid);
        $this->sql = "SELECT admission.AdmissionID, patientnotes.PatientNotesID, patientnotes.Notes, patientnotes.Time FROM patientnotes join admission on patientnotes.AdmissionID = admission.AdmissionID join patient on admission.PatientID = patient.PatientID WHERE admission.AdmissionID = '" . $admissionid . "'";
        $result = mysqli_query($this->connect, $this->sql);

        if (mysqli_num_rows($result) != 0) {

            $myArray = array();
            while ($row = mysqli_fetch_assoc($result)) {
                $myArray[] = $row;
            }

            echo json_encode($myArray);

        } else echo "None";
    }


    function getSingleNotes($patientnotesid)
    {
        $patientnotesid = $this->prepareData($patientnotesid);
        $this->sql = "SELECT patientnotes.Notes, patientnotes.Time FROM patientnotes WHERE PatientNotesID = '" . $patientnotesid . "'";
        $result = mysqli_query($this->connect, $this->sql);

        if (mysqli_num_rows($result) != 0) {

            $myArray = array();
            while ($row = mysqli_fetch_assoc($result)) {
                $myArray[] = $row;
            }

            echo json_encode($myArray);

        } else echo "None";
    }


    function modifyPatientNotes($patientnotesid, $notes, $datetime)
    {
        $patientnotesid = $this->prepareData($patientnotesid);
        $notes = $this->prepareData($notes);
        $datetime = $this->prepareData($datetime);

        $this->sql = "UPDATE patientnotes SET Notes = '" . $notes . "', Time = '" . $datetime . "'  WHERE patientnotes.PatientNotesID = '" . $patientnotesid . "'";
        $result = mysqli_query($this->connect, $this->sql);

        if ($result === true) {
            echo "Modified";
        } else echo "None";

    }


    function deletePatientNotes($patientnotesid)
    {
        $patientnotesid = $this->prepareData($patientnotesid);
        $this->sql = "DELETE FROM patientnotes WHERE patientnotes.PatientNotesID = '" . $patientnotesid . "'";
        $result = mysqli_query($this->connect, $this->sql);

        if ($result === true) {
            echo "Deleted";
        } else echo "None";

    }

    function getMedList()
    {
        $this->sql = "SELECT * FROM medication";
        $result = mysqli_query($this->connect, $this->sql);

        if (mysqli_num_rows($result) != 0) {

            $myArray = array();
            while ($row = mysqli_fetch_assoc($result)) {
                $myArray[] = $row;
            }

            echo json_encode($myArray);

        } else echo "None";

    }

    function addMedToAdmission($admissionid, $medicationid, $datetime, $doseamount)
    {
        $admissionid = $this->prepareData($admissionid);
        $medicationid = $this->prepareData($medicationid);
        $datetime = $this->prepareData($datetime);
        $doseamount = $this->prepareData($doseamount);


        $this->sql = "INSERT INTO medicationstay (MedicationStayID, MedicationID, AdmissionID, Amount,Time) VALUES (NULL, '" . $medicationid . "', '" . $admissionid . "' , '" . $doseamount . "', '" . $datetime . "')";
        $result = mysqli_query($this->connect, $this->sql);
        if ($result === true) {
            echo "Success";
        }
        echo "Not";

    }

    function fetClinList()
    {
        $this->sql = "SELECT * FROM clinician";
        $result = mysqli_query($this->connect, $this->sql);

        if (mysqli_num_rows($result) != 0) {

            $myArray = array();
            while ($row = mysqli_fetch_assoc($result)) {
                $myArray[] = $row;
            }

            echo json_encode($myArray);

        } else echo "None.";

    }

    function addClinToAdmission($admissionid, $clinicianid)
    {
        $admissionid = $this->prepareData($admissionid);
        $clinicianid = $this->prepareData($clinicianid);

        $this->sql = "select * from clinicianadmission where AdmissionID = '" . $admissionid . "' and ClinicianID = '" . $clinicianid . "'";
        $result = mysqli_query($this->connect, $this->sql);
        $row = mysqli_fetch_assoc($result);
        if (mysqli_num_rows($result) != 0) {
            echo "Clinician already in database.";
            return;
        } else {

            $this->sql = "INSERT INTO clinicianadmission (ClinicianAdmissionID, ClinicianID, AdmissionID, PushNotification) VALUES (NULL, '" . $clinicianid . "', '" . $admissionid . "', 1)";
            $result = mysqli_query($this->connect, $this->sql);
            if ($result === true) {
                echo "Success";
            } else echo "Could not insert clinician into database.";

        }


    }


    function addNotestoAdmission($admissionid, $notes, $datetime)
    {
        $admissionid = $this->prepareData($admissionid);
        $notes = $this->prepareData($notes);
        $datetime = $this->prepareData($datetime);

        $this->sql = "INSERT INTO patientnotes (PatientNotesID, AdmissionID, Notes, Time) VALUES (NULL, '" . $admissionid . "', '" . $notes . "', '" . $datetime . "')";
        $result = mysqli_query($this->connect, $this->sql);
        if ($result === true) {
            echo "Success";
        } else echo "None";

    }


    function getAdmissionClinList($admissionid)
    {
        $admissionid = $this->prepareData($admissionid);
        $this->sql = "SELECT clinicianadmission.ClinicianAdmissionID, clinician.ClinicianID, clinician.StaffNumber, clinician.ClinicianType FROM clinicianadmission join admission on clinicianadmission.AdmissionID = admission.AdmissionID join clinician on clinicianadmission.ClinicianID = clinician.ClinicianID WHERE clinicianadmission.AdmissionID = '" . $admissionid . "'";
        $result = mysqli_query($this->connect, $this->sql);

        if (mysqli_num_rows($result) != 0) {

            $myArray = array();
            while ($row = mysqli_fetch_assoc($result)) {
                $myArray[] = $row;
            }

            echo json_encode($myArray);

        } else echo "None";

    }

    function getClinicianDetails($clinicianid)
    {
        $clinicianid = $this->prepareData($clinicianid);

        $this->sql = "SELECT * FROM clinician WHERE ClinicianID = '" . $clinicianid . "'";
        $result = mysqli_query($this->connect, $this->sql);

        if (mysqli_num_rows($result) != 0) {
            $row = mysqli_fetch_assoc($result);
            $myArray = array();
            $myArray[] = $row;
            echo json_encode($myArray);
        } else echo "";

    }

    function delClinicianAdmission($clinicianadmissionid)
    {
        $clinicianadmissionid = $this->prepareData($clinicianadmissionid);
        $this->sql = "DELETE FROM clinicianadmission WHERE clinicianadmission.ClinicianAdmissionID = '" . $clinicianadmissionid . "'";
        $result = mysqli_query($this->connect, $this->sql);

        if ($result === true) {
            echo "Deleted";
        } else echo "";

    }


    //get patients assigned to specfic doctor
    function getAssignedPatients($username)
    {
        $username = $this->prepareData($username);
        $this->sql = "SELECT admission.AdmissionID, admission.PainType, admission.PainRegion, admission.Concerned, admission.Bed,patient.mrn, patient.PatientAge, patient.PatientGender, patient.PatientWeight, admission.Concerned, admission.StartTime, admission.EndTime , admission.Status, graph.GraphID FROM admission join graph on admission.AdmissionID = graph.AdmissionID join patient on admission.PatientID = patient.PatientID join clinicianadmission on clinicianadmission.AdmissionID = admission.AdmissionID join clinician on clinicianadmission.ClinicianID = clinician.ClinicianID join user on clinician.UserID = user.UserID WHERE admission.Status = 1 AND user.Username = '" . $username . "'";
        $result = mysqli_query($this->connect, $this->sql);

        if (mysqli_num_rows($result) != 0) {

            $myArray = array();
            while ($row = mysqli_fetch_assoc($result)) {
                $myArray[] = $row;

            }

            echo json_encode($myArray);

        } else return "No active patients.";

    }

    //get patients assigned to specfic doctor
    function getConcernedPatients($username)
    {
        $username = $this->prepareData($username);
        $this->sql = "SELECT admission.AdmissionID, admission.Concerned, admission.Bed,patient.mrn, patient.PatientAge, patient.PatientGender, patient.PatientWeight, admission.Concerned, admission.StartTime, admission.EndTime FROM admission join patient on admission.PatientID = patient.PatientID WHERE admission.Status = 1 AND admission.Concerned = 1";
        $result = mysqli_query($this->connect, $this->sql);

        if (mysqli_num_rows($result) != 0) {

            $myArray = array();
            while ($row = mysqli_fetch_assoc($result)) {
                $myArray[] = $row;

            }

            echo json_encode($myArray);

        } else return "No active patients.";

    }


    //modify a patient medication in medication stay
    function modifyMedicationAdmission($medicationstayid, $medicationid, $datetime, $amount)
    {
        $medicationstayid = $this->prepareData($medicationstayid);
        $medicationid = $this->prepareData($medicationid);
        $datetime = $this->prepareData($datetime);
        $amount = $this->prepareData($amount);

        $this->sql = "UPDATE medicationstay SET MedicationID = '" . $medicationid . "', Amount = '" . $amount . "' , Time = '" . $datetime . "' WHERE medicationstay.MedicationStayID = '" . $medicationstayid . "'";
        $result = mysqli_query($this->connect, $this->sql);

        if ($result === true) {
            echo "Modified";
        } else echo "None";

    }

    function addfeedback($admissionid, $q1, $q2, $q3, $q4)
    {
        $admissionid = $this->prepareData($admissionid);
        $q1 = $this->prepareData($q1);
        $q2 = $this->prepareData($q2);
        $q3 = $this->prepareData($q3);
        $q4 = $this->prepareData($q4);
        $this->sql = "select * from feedback where AdmissionID = '" . $admissionid . "'";
        $result = mysqli_query($this->connect, $this->sql);
        $row = mysqli_fetch_assoc($result);
        if (mysqli_num_rows($result) != 0) {
            echo "Feedback already added.";

        } else {
            $this->sql = "INSERT INTO feedback (FeedbackID ,AdmissionID, Question1, Question2, Question3, Question4) VALUES ( NULL, '" . $admissionid . "' , '" . $q1 . "', '" . $q2 . "', '" . $q3 . "', '" . $q4 . "')";

            if (mysqli_query($this->connect, $this->sql)) {
                echo "Added";
            } else echo "Could not add feedback.";

        }


    }

    function changeAdmissionStatus($admissionID)
    {
        $admissionID = $this->prepareData($admissionID);
        $this->sql = "UPDATE admission SET Status = 0 WHERE admission.AdmissionID = '" . $admissionID . "'";
        $result = mysqli_query($this->connect, $this->sql);

        if ($result === true) {

            date_default_timezone_set('Australia/Sydney');
            $date = date("Y-m-d H:i:s");
            $this->sql = "UPDATE admission SET EndTime = '" . $date . "'  WHERE admission.AdmissionID = '" . $admissionID . "'";
            $result = mysqli_query($this->connect, $this->sql);

            echo "Success";
        } else echo "Not";


    }

    function searchPatient($mrnnumber)
    {
        $mrnnumber = $this->prepareData($mrnnumber);
        $this->sql = "SELECT * FROM patient WHERE MRN = '" . $mrnnumber . "'";
        $result = mysqli_query($this->connect, $this->sql);

        if (mysqli_num_rows($result) != 0) {

            $myArray = array();
            while ($row = mysqli_fetch_assoc($result)) {
                $myArray[] = $row;

            }

            echo json_encode($myArray);

        } else echo "No active patients.";

    }

    function returnUsernameAndPassword($userid)
    {
        $userid = $this->prepareData($userid);
        $this->sql = "SELECT user.Username, user.Password FROM user WHERE UserID = '" . $userid . "'";
        $result = mysqli_query($this->connect, $this->sql);

        if (mysqli_num_rows($result) != 0) {

            $myArray = array();
            while ($row = mysqli_fetch_assoc($result)) {
                $myArray[] = $row;

            }

            echo json_encode($myArray);

        } else echo "Could not retrieve username and password.";

    }


    function updateUsernameAndPassword($username, $password, $userid)
    {
        $username = $this->prepareData($username);
        $password = $this->prepareData($password);
        $userid = $this->prepareData($userid);

        $this->sql = "UPDATE user SET Username = '" . $username . "', Password = '" . $password . "' WHERE user.UserID = '" . $userid . "'";
        $result = mysqli_query($this->connect, $this->sql);

        if ($result === true) {
            echo "Success";
        } else echo "Could not update username and password.";

    }


    function updatePatientInfo($userid, $mrn, $gender, $weight, $age)
    {
        $userid = $this->prepareData($userid);
        $mrn = $this->prepareData($mrn);
        $gender = $this->prepareData($gender);
        $weight = $this->prepareData($weight);
        $age = $this->prepareData($age);
        $this->sql = "UPDATE patient SET MRN = '" . $mrn . "', PatientGender = '" . $gender . "', PatientWeight =  '" . $weight . "', PatientAge = '" . $age . "' WHERE patient.UserID = '" . $userid . "'";
        $result = mysqli_query($this->connect, $this->sql);

        if ($result === true) {
            echo "Success";
        } else echo "Could not update patient info.";


    }


    function deletePatientAndUser($userid, $patientid)
    {
        $userid = $this->prepareData($userid);
        $patientid = $this->prepareData($patientid);

        $this->sql = "DELETE graphvalue FROM graphvalue join graph on graph.GraphID = graphvalue.GraphID join admission on graph.AdmissionID = admission.AdmissionID join patient on patient.PatientID = admission.PatientID WHERE patient.PatientID = '" . $patientid . "'";
        $result = mysqli_query($this->connect, $this->sql);
        $this->sql = "DELETE graph FROM graph join admission on graph.AdmissionID = admission.AdmissionID join patient on patient.PatientID = admission.PatientID WHERE patient.PatientID = '" . $patientid . "'";
        $result = mysqli_query($this->connect, $this->sql);
        $this->sql = "DELETE feedback FROM feedback join admission on feedback.AdmissionID = admission.AdmissionID join patient on patient.PatientID = admission.PatientID WHERE patient.PatientID = '" . $patientid . "'";
        $result = mysqli_query($this->connect, $this->sql);
        $this->sql = "DELETE patientnotes FROM patientnotes join admission on patientnotes.AdmissionID = admission.AdmissionID join patient on patient.PatientID = admission.PatientID WHERE patient.PatientID = '" . $patientid . "'";
        $result = mysqli_query($this->connect, $this->sql);
        $this->sql = "DELETE medicationstay FROM medicationstay join admission on medicationstay.AdmissionID = admission.AdmissionID join patient on patient.PatientID = admission.PatientID WHERE patient.PatientID = '" . $patientid . "'";
        $result = mysqli_query($this->connect, $this->sql);
        $this->sql = "DELETE clinicianadmission FROM clinicianadmission join admission on clinicianadmission.AdmissionID = admission.AdmissionID join patient on patient.PatientID = admission.PatientID WHERE patient.PatientID = '" . $patientid . "'";
        $result = mysqli_query($this->connect, $this->sql);
        $this->sql = "DELETE FROM admission WHERE admission.PatientID = '" . $patientid . "'";
        $result = mysqli_query($this->connect, $this->sql);

        $this->sql = "DELETE FROM patient WHERE patient.UserID = '" . $userid . "'";
        $result = mysqli_query($this->connect, $this->sql);
        if ($result === true) {
            $this->sql = "DELETE FROM user WHERE user.UserID = '" . $userid . "'";
            $result = mysqli_query($this->connect, $this->sql);
            if ($result === true) {
                echo "Deleted";
            } else echo "Could not delete user.";

        } else echo "Could not delete patient.";

    }

    function deletePatientAndUserSingle($userid, $patientid)
    {
        $userid = $this->prepareData($userid);
        $patientid = $this->prepareData($patientid);


        $this->sql = "DELETE FROM patient WHERE patient.UserID = '" . $userid . "'";
        $result = mysqli_query($this->connect, $this->sql);
        if ($result === true) {
            $this->sql = "DELETE FROM user WHERE user.UserID = '" . $userid . "'";
            $result = mysqli_query($this->connect, $this->sql);
            if ($result === true) {
                echo "Deleted";
            } else echo "Could not delete user.";

        } else echo "Could not delete patient.";

    }


    function getRoleList()
    {
        $this->sql = "SELECT * FROM role";

        $result = mysqli_query($this->connect, $this->sql);

        if (mysqli_num_rows($result) != 0) {

            $myArray = array();
            while ($row = mysqli_fetch_assoc($result)) {
                $myArray[] = $row;

            }

            echo json_encode($myArray);

        } else return "No roles.";

    }

    function addRoleToDatabase($rolename, $rolepower)
    {
        $rolename = $this->prepareData($rolename);
        $rolepower = $this->prepareData($rolepower);

        $this->sql = "INSERT INTO role (RoleID, RoleName, RolePower) VALUES (NULL, '" . $rolename . "', '" . $rolepower . "')";

        if (mysqli_query($this->connect, $this->sql)) {
            echo "Success";
        } else echo "Could not add role.";

    }

    function modifyRole($roleid, $rolename, $rolepower)
    {
        $roleid = $this->prepareData($roleid);
        $rolename = $this->prepareData($rolename);
        $rolepower = $this->prepareData($rolepower);

        $this->sql = "UPDATE role SET RoleName = '" . $rolename . "', RolePower = '" . $rolepower . "' WHERE role.RoleID = '" . $roleid . "'";
        $result = mysqli_query($this->connect, $this->sql);

        if ($result === true) {
            echo "Success";
        } else echo "";


    }

    function deleteRole($roleid)
    {
        $roleid = $this->prepareData($roleid);
        $this->sql = "DELETE FROM role WHERE role.RoleID = '" . $roleid . "'";
        $result = mysqli_query($this->connect, $this->sql);
        if ($result === true) {
            echo "Deleted";
        } else echo "";
    }


    function getMedsForList()
    {
        $this->sql = "SELECT * FROM medication";

        $result = mysqli_query($this->connect, $this->sql);

        if (mysqli_num_rows($result) != 0) {

            $myArray = array();
            while ($row = mysqli_fetch_assoc($result)) {
                $myArray[] = $row;

            }

            echo json_encode($myArray);

        } else echo "No medications.";


    }


    function modifyMedicationAdmin($medicationid, $medbrand, $medchem, $dosage, $doseform)
    {
        $medicationid = $this->prepareData($medicationid);
        $medbrand = $this->prepareData($medbrand);
        $medchem = $this->prepareData($medchem);
        $dosage = $this->prepareData($dosage);
        $doseform = $this->prepareData($doseform);

        $this->sql = "UPDATE medication SET MedBrand = '" . $medbrand . "', MedChemName = '" . $medchem . "', Dosage = '" . $dosage . "', DoseForm = '" . $DoseForm . "' WHERE medication.MedicationID = '" . $medicationid . "' ";

        $result = mysqli_query($this->connect, $this->sql);
        if ($result == true) {
            echo "Success";
        } else echo "Not";
    }


    function deletemedicationFromMeds($medicationid)
    {
        $medicationid = $this->prepareData($medicationid);
        $this->sql = "DELETE FROM medication WHERE medication.MedicationID = '" . $medicationid . "'";
        $result = mysqli_query($this->connect, $this->sql);
        if ($result === true) {
            echo "Deleted";
        } else echo "None";

    }


    function deleteAllMedsFromBase($medicationid)
    {
        $medicationid = $this->prepareData($medicationid);

        $this->sql = "DELETE medicationstay FROM medicationstay WHERE medicationstay.MedicationID = '" . $medicationid . "'";
        $result = mysqli_query($this->connect, $this->sql);
        if ($result === true) {
            $this->sql = "DELETE FROM medication WHERE medication.MedicationID = '" . $medicationid . "'";
            $result = mysqli_query($this->connect, $this->sql);
            if ($result == true) {
                echo "Deleted";
            } else echo "Could not delete medication.";
        } else {
            echo "Could not delete from admissions.";
        }

    }


    function addmedicationNew($medbrand, $chemname, $dose, $doseform)
    {

        $medbrand = $this->prepareData($medbrand);
        $chemname = $this->prepareData($chemname);
        $dose = $this->prepareData($dose);
        $doseform = $this->prepareData($doseform);
        $this->sql = "INSERT INTO medication (MedicationID, MedBrand, MedChemName, Dosage, DoseForm) VALUES ( NULL, '" . $medbrand . "', '" . $chemname . "' , '" . $dose . "', '" . $doseform . "')";


        if (mysqli_query($this->connect, $this->sql)) {
            echo "Success";
        } else echo "Could not add medication.";


    }


    function addNewClinician($username, $password, $staffnumber, $clintype)
    {
        $staffnumber = $this->prepareData($staffnumber);
        $clintype = $this->prepareData($clintype);
        $username = $this->prepareData($username);
        $password = $this->prepareData($password);
        $user;

        $this->sql = "select * from clinician where StaffNumber = '" . $staffnumber . "'";
        $result = mysqli_query($this->connect, $this->sql);
        $row = mysqli_fetch_assoc($result);
        if (mysqli_num_rows($result) != 0) {
            echo "Staff number in use.";
            return;
        }

        $this->sql = "select * from user where Username = '" . $username . "'";
        $result = mysqli_query($this->connect, $this->sql);
        $row = mysqli_fetch_assoc($result);
        if (mysqli_num_rows($result) != 0) {
            echo "Username in use.";
            return;
        }

        $this->sql = "INSERT INTO user (UserID, RoleID, Username, Password, Token) VALUES (NULL, '2', '" . $username . "', '" . $password . "', NULL)";
        if (mysqli_query($this->connect, $this->sql)) {

        } else {
            echo "Insert into user failed.";
            return;
        }


        $this->sql = "select * from user where Username = '" . $username . "'";
        $result = mysqli_query($this->connect, $this->sql);
        $row = mysqli_fetch_assoc($result);
        if (mysqli_num_rows($result) != 0) {
            $user = $row['UserID'];
            $this->sql = "INSERT INTO clinician (ClinicianID, UserID, StaffNumber, ClinicianType) VALUES (NULL , '" . $user . "','" . $staffnumber . "','" . $clintype . "')";

            if (mysqli_query($this->connect, $this->sql)) {
                echo "Success";
            } else echo "Could not insert clinician.";

        } else echo "Could not get user name";

    }


    function searchClinician($staffnumber)
    {
        $staffnumber = $this->prepareData($staffnumber);
        $this->sql = "SELECT * FROM clinician WHERE Staffnumber = '" . $staffnumber . "'";
        $result = mysqli_query($this->connect, $this->sql);

        if (mysqli_num_rows($result) != 0) {

            $myArray = array();
            while ($row = mysqli_fetch_assoc($result)) {
                $myArray[] = $row;

            }

            echo json_encode($myArray);

        } else echo "No Clinician with that staffnumber.";

    }


    function updateClinicianInfo($staffnumber, $cliniciantype, $userid)
    {
        $staffnumber = $this->prepareData($staffnumber);
        $cliniciantype = $this->prepareData($cliniciantype);
        $userid = $this->prepareData($userid);
        $this->sql = "UPDATE clinician SET StaffNumber = '" . $staffnumber . "', ClinicianType = '" . $cliniciantype . "' WHERE clinician.UserID = '" . $userid . "'";
        $result = mysqli_query($this->connect, $this->sql);

        if ($result === true) {
            echo "Success";
        } else echo "Could not update clinician information.";

    }

    function deleteClinicianAndUser($userid)
    {
        $userid = $this->prepareData($userid);
        $this->sql = "DELETE FROM clinician WHERE clinician.UserID = '" . $userid . "'";
        $result = mysqli_query($this->connect, $this->sql);
        if ($result === true) {
            $this->sql = "DELETE FROM user WHERE user.UserID = '" . $userid . "'";
            $result = mysqli_query($this->connect, $this->sql);
            if ($result === true) {
                echo "Deleted";
            } else echo "Could not delete from user.";

        } else echo "Could not delete from clinician.";


    }

    function deleteAllRecordOfClinician($userid, $staffNumber)
    {
        $userid = $this->prepareData($userid);
        $staffNumber = $this->prepareData($staffNumber);

        $this->sql = "DELETE clinicianadmission FROM clinicianadmission join clinician on clinician.ClinicianID = clinicianadmission.ClinicianID WHERE clinician.StaffNumber = '" . $staffNumber . "'";
        $result = mysqli_query($this->connect, $this->sql);
        if ($result === false) {
            echo "Could not delete from admission.";
            return;
        }


        $this->sql = "DELETE FROM clinician WHERE clinician.UserID = '" . $userid . "'";
        $result = mysqli_query($this->connect, $this->sql);
        if ($result === true) {
            $this->sql = "DELETE FROM user WHERE user.UserID = '" . $userid . "'";
            $result = mysqli_query($this->connect, $this->sql);
            if ($result === true) {
                echo "Deleted";
            } else echo "Could not delete from user.";

        } else echo "Could not delete from clinician.";

    }


    function searchAdmissionMrn($mrn)
    {

        $mrn = $this->prepareData($mrn);
        $this->sql = "SELECT admission.AdmissionID, admission.Bed, graph.GraphID, admission.Concerned, admission.StartTime, admission.EndTime, admission.Status, admission.PainType, admission.PainRegion, admission.PatientID, patient.MRN, patient.PatientAge, patient.PatientGender FROM admission left join patient on admission.PatientID = patient.PatientID join graph on admission.AdmissionID = graph.AdmissionID WHERE MRN = '" . $mrn . "'";
        $result = mysqli_query($this->connect, $this->sql);

        if (mysqli_num_rows($result) != 0) {

            $myArray = array();

            while ($row = mysqli_fetch_assoc($result)) {
                $myArray[] = $row;

            }

            echo json_encode($myArray);

        }
        echo "No admissions for mrn.";


    }


    function searchAdmissionStaffNumber($staffnumber)
    {
        $staffnumber = $this->prepareData($staffnumber);
        $this->sql = "SELECT admission.AdmissionID, admission.PatientID, admission.Concerned, admission.PainType, admission.PainRegion, admission.Status, admission.StartTime, admission.EndTime, admission.Bed,clinician.StaffNumber ,patient.MRN, patient.PatientAge, patient.PatientGender, graph.GraphID FROM admission join patient on admission.PatientID = patient.PatientID join clinicianadmission on clinicianadmission.AdmissionID = admission.AdmissionID join clinician on clinicianadmission.ClinicianID = clinician.ClinicianID join graph on graph.AdmissionID = admission.AdmissionID WHERE StaffNumber = '" . $staffnumber . "'";
        $result = mysqli_query($this->connect, $this->sql);


        if (mysqli_num_rows($result) != 0) {

            $myArray = array();

            while ($row = mysqli_fetch_assoc($result)) {
                $myArray[] = $row;

            }

            echo json_encode($myArray);

        } else echo "No search results.";
    }


    function deleteAdmissionAdmin($admissionid)
    {
        $admissionid = $this->prepareData($admissionid);
        $this->sql = "DELETE graphvalue FROM graphvalue join graph on graph.GraphID = graphvalue.GraphID join admission on graph.AdmissionID = admission.AdmissionID WHERE admission.AdmissionID = '" . $admissionid . "'";
        $result = mysqli_query($this->connect, $this->sql);
        $this->sql = "DELETE graph FROM graph join admission on graph.AdmissionID = admission.AdmissionID WHERE admission.AdmissionID = '" . $admissionid . "'";
        $result = mysqli_query($this->connect, $this->sql);
        $this->sql = "DELETE feedback FROM feedback join admission on feedback.AdmissionID = admission.AdmissionID WHERE admission.AdmissionID = '" . $admissionid . "'";
        $result = mysqli_query($this->connect, $this->sql);
        $this->sql = "DELETE patientnotes FROM patientnotes join admission on patientnotes.AdmissionID = admission.AdmissionID WHERE admission.AdmissionID = '" . $admissionid . "'";
        $result = mysqli_query($this->connect, $this->sql);
        $this->sql = "DELETE medicationstay FROM medicationstay join admission on medicationstay.AdmissionID = admission.AdmissionID WHERE admission.AdmissionID = '" . $admissionid . "'";
        $result = mysqli_query($this->connect, $this->sql);
        $this->sql = "DELETE clinicianadmission FROM clinicianadmission  join admission on clinicianadmission.AdmissionID = admission.AdmissionID WHERE admission.AdmissionID = '" . $admissionid . "'";
        $result = mysqli_query($this->connect, $this->sql);
        $this->sql = "DELETE FROM admission WHERE admission.AdmissionID = '" . $admissionid . "'";
        $result = mysqli_query($this->connect, $this->sql);
        if ($result === true) {
            echo "Deleted";
        } else echo "Not";


    }


    function admissionReturnForPain($username)
    {
        $username = $this->prepareData($username);
        $this->sql = "SELECT admission.AdmissionID, graph.GraphID, admission.PatientID, patient.MRN FROM admission join patient on patient.PatientID = admission.PatientID join user on patient.UserID = user.UserID join graph on graph.AdmissionID = admission.AdmissionID WHERE user.Username = '" . $username . "' and admission.Status = 1";
        $result = mysqli_query($this->connect, $this->sql);

        if (mysqli_num_rows($result) != 0) {
            $myArray = array();
            $row = mysqli_fetch_assoc($result);
            $myArray[] = $row;
            echo json_encode($myArray);
        } else echo " ";

    }


    function onPainInput($admissionid, $graphid, $painscore)
    {

        $admissionid = $this->prepareData($admissionid);
        $graphid = $this->prepareData($graphid);
        $painscore = $this->prepareData($painscore);
        $this->sql = "SELECT graphvalue.PainScore FROM graphvalue WHERE graphvalue.GraphID = '" . $graphid . "'";
        $result = mysqli_query($this->connect, $this->sql);
        $value = 6;
        $numResults = mysqli_num_rows($result);
        $counter = 0;
        $timemax = 0;
        $time2 = 0;

        if ($numResults > 0) {

            $timemax = strtotime($row["Time"]);
            $value = $row["PainScore"];

            while ($row = mysqli_fetch_assoc($result)) {
                $time2 = strtotime($row["Time"]);

                if ($time2 > $timemax) {
                    $value = $row["PainScore"];
                    $timemax = $time2;
                }
            }
        }


        if ($painscore >= 6 || ($painscore >= $value)) {

            $this->sql = "SELECT user.Token FROM clinicianadmission join clinician on clinician.ClinicianID = clinicianadmission.ClinicianID join user on clinician.UserID = user.UserID WHERE clinicianadmission.AdmissionID = '" . $admissionid . "'";
            $result = mysqli_query($this->connect, $this->sql);
            if (mysqli_num_rows($result) != 0) {
                while ($row = mysqli_fetch_assoc($result)) {
                    if (strlen($row["Token"]) > 0) {
                        $painstring = "Pain score: '" . $painscore . "'";
                        $admissionid23 = "AdmissionID: '" . $admissionid . "'";
                        $data = array('title' => $admissionid23, 'body' => $painstring);
                        $this->notify($row["Token"], $data);
                    }
                }
            }

            $this->sql = "UPDATE admission SET Concerned = 1 where admission.AdmissionID = '" . $admissionid . "' ";
            $result = mysqli_query($this->connect, $this->sql);
        } else {
            $this->sql = "UPDATE admission SET Concerned = 0 where admission.AdmissionID = '" . $admissionid . "' ";
            $result = mysqli_query($this->connect, $this->sql);
        }


        date_default_timezone_set('Australia/Sydney');
        $date = date("Y-m-d H:i:s");
        $this->sql = "INSERT INTO graphvalue (GraphValueID, GraphID, PainScore, Time) VALUES (NULL, '" . $graphid . "', '" . $painscore . "', '" . $date . "')";
        if (mysqli_query($this->connect, $this->sql)) {
            echo "Success";
        } else echo "Could not add pain score.";

    }

    function send15Notification($mrn)
    {
        $mrn = $this->prepareData($mrn);
        $this->sql = "SELECT user.Token FROM user join patient on patient.UserID = user.UserID WHERE patient.MRN = '" . $mrn . "'";
        $result = mysqli_query($this->connect, $this->sql);
        if (mysqli_num_rows($result) != 0) {
            $data = array('title' => 'Reminder', 'body' => 'Please input pain score.');
            $row = mysqli_fetch_assoc($result);
            $this->notify($row["Token"], $data);
            echo $row["Token"];
        }
    }


    function notify($to, $data)
    {

        $api_key = "AAAA0IGmH6c:APA91bHdMU38B7cczxwb9uggZTfZ2wupkU5yuGv9Nb0O5D1_ShGKsX8uOvrqNlhHp-GlsofrqCF5V2lds7E46Pf5MuPRmwwr3xCbT1Nj8onDM2NKZxVJTEc39MtaNFlHv7mDZfA8hSe-";
        $url = "https://fcm.googleapis.com/fcm/send";
        $fields = json_encode(array('to' => $to, 'notification' => $data));

        // Generated by curl-to-PHP: http://incarnate.github.io/curl-to-php/
        $ch = curl_init();

        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, ($fields));

        $headers = array();
        $headers[] = 'Authorization: key =' . $api_key;
        $headers[] = 'Content-Type: application/json';
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

        $result = curl_exec($ch);
        if (curl_errno($ch)) {
            echo 'Error:' . curl_error($ch);
        }
        curl_close($ch);
    }


    function getLastValueOfPainForButton($graphid, $maxtimer)
    {
        $graphid = $this->prepareData($graphid);
        $maxtimer = $this->prepareData($maxtimer);
        $this->sql = "SELECT graphvalue.Time FROM graphvalue WHERE graphvalue.GraphID = '" . $graphid . "'";
        $result = mysqli_query($this->connect, $this->sql);
        $value = 0;
        $numResults = mysqli_num_rows($result);
        $counter = 0;
        date_default_timezone_set('Australia/Sydney');

        $timemax = 0;
        $time2 = 0;

        if ($numResults > 0) {

            $timemax = strtotime($row["Time"]);
            $value = $row["Time"];

            while ($row = mysqli_fetch_assoc($result)) {
                $time2 = strtotime($row["Time"]);

                if ($time2 > $timemax) {
                    $value = $row["Time"];
                    $timemax = $time2;
                }
            }

            $dbtimestamp = strtotime($value);
            if (time() - $dbtimestamp > $maxtimer * 60) {
                echo "true";
            } else {
                $timesendback = time() - $dbtimestamp;
                echo $timesendback;
            }
        } else echo "true";
    }


    function getPatientMrn($username)
    {
        $username = $this->prepareData($username);
        $this->sql = "SELECT patient.MRN FROM patient join user on user.UserID = patient.UserID WHERE user.UserName = '" . $username . "'";
        $result = mysqli_query($this->connect, $this->sql);
        if (mysqli_num_rows($result) != 0) {
            $row = mysqli_fetch_assoc($result);
            echo $row["MRN"];
        } else echo "false";

    }

    function getAUC($admissionid)
    {
        $admissionid = $this->prepareData($admissionid);
        $this->sql = "SELECT graphvalue.PainScore FROM graphvalue join graph on graph.GraphID = graphvalue.GraphID join admission on admission.AdmissionID = graph.AdmissionID WHERE admission.AdmissionID = '" . $admissionid . "'";
        $result = mysqli_query($this->connect, $this->sql);
        $value = 0;
        $numResults = mysqli_num_rows($result);

        if ($numResults > 0) {
            while ($row = mysqli_fetch_assoc($result)) {

                $value += $row["PainScore"];
            }
        }

        $AUC = array('AUC' => (string)$value);
        echo json_encode($AUC);


    }

    function modifyBed($admissionid, $bednumber)
    {
        $admissionid = $this->prepareData($admissionid);
        $bednumber = $this->prepareData($bednumber);
        $this->sql = "UPDATE admission SET Bed = '" . $bednumber . "' where admission.AdmissionID = '" . $admissionid . "' ";
        $result = mysqli_query($this->connect, $this->sql);

        if ($result == true) {
            echo "Success";
        } else echo "Not";


    }

    function getGraphID($admissionid)
    {
        $admissionid = $this->prepareData($admissionid);
        $this->sql = "SELECT graph.GraphID FROM graph WHERE graph.AdmissionID = '" . $admissionid . "' ";
        $result = mysqli_query($this->connect, $this->sql);

        if (mysqli_num_rows($result) == 1) {
            $row = mysqli_fetch_assoc($result);
            echo $row["GraphID"];
        } else echo "Not";

    }

    function checkIfConcerned($admissionid)
    {

        $admissionid = $this->prepareData($admissionid);
        $this->sql = "SELECT admission.Concerned FROM admission WHERE admission.AdmissionID = '" . $admissionid . "' AND admission.Status = 1 ";
        $result = mysqli_query($this->connect, $this->sql);

        if (mysqli_num_rows($result) == 1) {
            $row = mysqli_fetch_assoc($result);
            echo $row["Concerned"];
        } else echo "Not";

    }

    function retClientDetails($admissionid)
    {

        $this->sql = "SELECT admission.AdmissionID, admission.Bed, admission.Concerned, admission.StartTime, admission.EndTime, admission.PainTimer,patient.mrn, patient.PatientAge, patient.PatientGender, patient.PatientWeight FROM admission join patient on admission.PatientID = patient.PatientID WHERE admission.AdmissionID = '" . $admissionid . "' AND admission.Status = 1";


        $result = mysqli_query($this->connect, $this->sql);

        if (mysqli_num_rows($result) != 0) {

            $myArray = array();
            $row = mysqli_fetch_assoc($result);
            $myArray[] = $row;
            echo json_encode($myArray);

        } else return "No active admissions.";

    }

    function updateMedicationInfo($medicationid, $medbrand, $medchem, $dosage, $doseform)
    {
        $this->sql = "UPDATE medication SET MedBrand = '" . $medbrand . "', MedChemName = '" . $medchem . "', Dosage = '" . $dosage . "', DoseForm = '" . $doseform . "' WHERE medication.MedicationID = '" . $medicationid . "'";
        $result = mysqli_query($this->connect, $this->sql);

        if ($result === true) {
            echo "Success";
        } else echo "None";
    }

    function getTimerForGraph($admissionid)
    {
        $admissionid = $this->prepareData($admissionid);
        $this->sql = "SELECT admission.PainTimer FROM admission WHERE admission.AdmissionID = '" . $admissionid . "' ";
        $result = mysqli_query($this->connect, $this->sql);

        if (mysqli_num_rows($result) == 1) {
            $row = mysqli_fetch_assoc($result);
            echo $row["PainTimer"];
        } else echo "Not";
    }

    function getAdmissionTime($admissionid)
    {
        $admissionid = $this->prepareData($admissionid);
        $this->sql = "SELECT * FROM admission WHERE admission.AdmissionID = '" . $admissionid . "' ";
        $result = mysqli_query($this->connect, $this->sql);

        if (mysqli_num_rows($result) != 0) {

            $myArray = array();
            $row = mysqli_fetch_assoc($result);
            $myArray[] = $row;
            echo json_encode($myArray);

        } else return "Not";

    }

    function updateAdmissionStatus($admissionid, $status)
    {
        $admissionid = $this->prepareData($admissionid);
        $status = $this->prepareData($status);


        $this->sql = "UPDATE admission SET Status = '" . $status . "' WHERE admission.AdmissionID = '" . $admissionid . "'";
        $result = mysqli_query($this->connect, $this->sql);

        if ($result === true) {
            echo "Success";
            if ($status == "0") {
                date_default_timezone_set('Australia/Sydney');
                $date = date("Y-m-d H:i:s");
                $this->sql = "UPDATE admission SET EndTime = '" . $date . "'  WHERE admission.AdmissionID = '" . $admissionid . "'";
                $result = mysqli_query($this->connect, $this->sql);
            }
        } else echo "Not";


    }

    function modifyPainTimerAdmission($admissionid, $paintimer)
    {
        $admissionid = $this->prepareData($admissionid);
        $paintimer = $this->prepareData($paintimer);

        $this->sql = "UPDATE admission SET PainTimer = '" . $paintimer . "' WHERE admission.AdmissionID = '" . $admissionid . "'";
        $result = mysqli_query($this->connect, $this->sql);

        if ($result === true) {
            echo "Success";
        } else echo "Not";
    }

    function modifyAdmissionTime($admissionid, $starttime, $endtime)
    {
        $admissionid = $this->prepareData($admissionid);
        $starttime = $this->prepareData($starttime);
        $endtime = $this->prepareData($endtime);
        $this->sql = "UPDATE admission SET StartTime = '" . $starttime . "', EndTime = '" . $endtime . "'  WHERE admission.AdmissionID = '" . $admissionid . "'";
        $result = mysqli_query($this->connect, $this->sql);

        if ($result === true) {
            echo "Success";
        } else echo "Not";
    }


    function checkIfFeedbackAdded($admissionid)
    {
        $admissionid = $this->prepareData($admissionid);
        $this->sql = "SELECT * FROM feedback WHERE feedback.AdmissionID = '" . $admissionid . "' ";
        $result = mysqli_query($this->connect, $this->sql);

        if (mysqli_num_rows($result) != 0) {
            echo "added";
        } else echo "not added";

    }

    function getGraphValuesAndTime($graphid)
    {
        $graphid = $this->prepareData($graphid);
        $this->sql = "SELECT * FROM graphvalue WHERE graphvalue.GraphID = '" . $graphid . "' ";
        $result = mysqli_query($this->connect, $this->sql);

        if (mysqli_num_rows($result) != 0) {
            $myArray = array();

            while ($row = mysqli_fetch_assoc($result)) {
                $myArray[] = $row;

            }

            echo json_encode($myArray);
        } else echo "Not";

    }

    function deleteFeedback($admissionid)
    {
        $admissionid = $this->prepareData($admissionid);
        $this->sql = "DELETE FROM feedback WHERE feedback.AdmissionID = '" . $admissionid . "' ";
        $result = mysqli_query($this->connect, $this->sql);

        if ($result === true) {
            echo "Success";
        } else echo "Not";

    }

    function getAdmissionValues($admissionid)
    {
        $admissionid = $this->prepareData($admissionid);
        $this->sql = "SELECT * FROM feedback WHERE feedback.AdmissionID = '" . $admissionid . "' ";
        $result = mysqli_query($this->connect, $this->sql);

        if (mysqli_num_rows($result) != 0) {
            $myArray = array();

            while ($row = mysqli_fetch_assoc($result)) {
                $myArray[] = $row;

            }

            echo json_encode($myArray);
        } else echo "Not";

    }

    function modifyfeedback($admissionid, $q1, $q2, $q3, $q4)
    {
        $admissionid = $this->prepareData($admissionid);
        $q1 = $this->prepareData($q1);
        $q2 = $this->prepareData($q2);
        $q3 = $this->prepareData($q3);
        $q4 = $this->prepareData($q4);
        $this->sql = "UPDATE feedback SET Question1 = '" . $q1 . "', Question2 = '" . $q2 . "', Question3 = '" . $q3 . "', Question4 = '" . $q4 . "'  where feedback.AdmissionID = '" . $admissionid . "'";
        $result = mysqli_query($this->connect, $this->sql);
        if ($result === true) {
            echo "Success";
        } else echo "Not";

    }


    function onPainInputClinAdmin($admissionid, $graphid, $painscore, $datetime)
    {

        $admissionid = $this->prepareData($admissionid);
        $graphid = $this->prepareData($graphid);
        $painscore = $this->prepareData($painscore);
        $datetime = $this->prepareData($datetime);
        $this->sql = "SELECT graphvalue.PainScore, graphvalue.Time FROM graphvalue WHERE graphvalue.GraphID = '" . $graphid . "'";
        $result = mysqli_query($this->connect, $this->sql);
        $value = 6;
        $numResults = mysqli_num_rows($result);
        $counter = 0;
        $timemax = 0;
        $time2 = 0;
        date_default_timezone_set('Australia/Sydney');

        if ($numResults > 0) {

            $timemax = strtotime($row["Time"]);
            $value = $row["PainScore"];

            while ($row = mysqli_fetch_assoc($result)) {
                $time2 = strtotime($row["Time"]);

                if ($time2 > $timemax) {
                    $value = $row["PainScore"];
                    $timemax = $time2;
                }
            }
        }


        if (strtotime($datetime) > $timemax) {
            if ($painscore >= 6 || ($painscore >= $value)) {
                $this->sql = "SELECT user.Token FROM clinicianadmission join clinician on clinician.ClinicianID = clinicianadmission.ClinicianID join user on clinician.UserID = user.UserID WHERE clinicianadmission.AdmissionID = '" . $admissionid . "'";
                $result = mysqli_query($this->connect, $this->sql);
                if (mysqli_num_rows($result) != 0) {
                    while ($row = mysqli_fetch_assoc($result)) {
                        if (strlen($row["Token"]) > 0) {
                            $painstring = "Pain score: '" . $painscore . "'";
                            $admissionid23 = "AdmissionID: '" . $admissionid . "'";
                            $data = array('title' => $admissionid23, 'body' => $painstring);
                            $this->notify($row["Token"], $data);
                        }
                    }
                }

                $this->sql = "UPDATE admission SET Concerned = 1 where admission.AdmissionID = '".$admissionid."'";
                mysqli_query($this->connect, $this->sql);
            } else {
                $this->sql = "UPDATE admission SET Concerned = 0 where admission.AdmissionID = '" . $admissionid . "' ";
                mysqli_query($this->connect, $this->sql);
            }
        }


        $this->sql = "INSERT INTO graphvalue (GraphValueID, GraphID, PainScore, Time) VALUES (NULL, '" . $graphid . "', '" . $painscore . "', '" . $datetime . "')";
        if (mysqli_query($this->connect, $this->sql)) {
            echo "Success";
        } else echo "Not";

    }


    function deleteGraphValue($graphvalueid)
    {
        $graphvalueid = $this->prepareData($graphvalueid);
        $this->sql = "DELETE FROM graphvalue WHERE graphvalue.GraphValueID = '" . $graphvalueid . "'";
        $result = mysqli_query($this->connect, $this->sql);
        if ($result === true) {
            echo "Deleted";
        } else echo "";
       
    }

    function getPainDetails($admissionid)
    {
        $admissionid = $this->prepareData($admissionid);
        $this->sql = "SELECT * FROM admission WHERE admission.AdmissionID = '" . $admissionid . "' ";
        $result = mysqli_query($this->connect, $this->sql);

        if (mysqli_num_rows($result) != 0) {
            $myArray = array();

            while ($row = mysqli_fetch_assoc($result)) {
                $myArray[] = $row;

            }

            echo json_encode($myArray);
        } else echo "Not";

    }

    function modifyPainAdmission($admissionid, $painregion, $paintype)
    {
        $admissionid = $this->prepareData($admissionid);
        $painregion = $this->prepareData($painregion);
        $paintype = $this->prepareData($paintype);
        $this->sql = "UPDATE admission SET PainRegion = '" . $painregion . "', PainType = '" . $paintype . "' where admission.AdmissionID = '" . $admissionid . "' ";
        $result = mysqli_query($this->connect, $this->sql);

        if ($result == true) {
            echo "Success";
        } else echo "Not";
    }

    function searchMedicationWild($searchstring)
    {
        $searchstring = $this->prepareData($searchstring);
        $this->sql = "SELECT * FROM medication WHERE MedBrand like '%" . $searchstring . "%' OR MedChemName like '%" . $searchstring . "%' ";
        $result = mysqli_query($this->connect, $this->sql);

        if ($result) {

            $myArray = array();
            while ($row = mysqli_fetch_assoc($result)) {
                $myArray[] = $row;

            }

            echo json_encode($myArray);

        } else echo "No Medication.";

    }

    function getAllAdmissionDet($admissionid)
    {
        //$admissionid = $this->prepareData($admissionid);
        $this->sql = "SELECT admission.Bed, admission.Status, admission.StartTime, admission.EndTime, admission.PainType, admission.PainRegion, admission.PainTimer FROM admission WHERE admission.AdmissionID = '" . $admissionid . "'";
        $result = mysqli_query($this->connect, $this->sql);

        if ($result) {
            $myArray = array();
            while ($row = mysqli_fetch_assoc($result)) {
                $myArray[] = $row;

            }

            echo json_encode($myArray);
        } else echo "Not";
    }

    function getAllAdmissionDetGraph($admissionid)
    {
        //$admissionid = $this->prepareData($admissionid);
        $this->sql = "SELECT admission.Bed, admission.Concerned, patient.PatientGender, graph.GraphID FROM admission join patient on admission.PatientID = patient.PatientID join graph on graph.AdmissionID = admission.AdmissionID WHERE admission.AdmissionID = '" . $admissionid . "'";
        $result = mysqli_query($this->connect, $this->sql);

        if ($result) {
            $myArray = array();
            while ($row = mysqli_fetch_assoc($result)) {
                $myArray[] = $row;

            }

            echo json_encode($myArray);
        } else echo "None";
    }
}
