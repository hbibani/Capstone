<?php
require "DataBase.php";
$db = new DataBase();




if (isset($_POST['admissionid']) && isset($_POST['paintimer'])  ) 
{
    if ($db->dbConnect()) 
    {
        $db->modifyPainTimerAdmission($_POST['admissionid'], $_POST['paintimer']);
    } 
    else echo "Error: Database connection";
} 
else echo "All fields are required";


?>
