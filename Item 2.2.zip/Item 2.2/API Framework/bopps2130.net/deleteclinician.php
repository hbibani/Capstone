<?php
require "DataBase.php";
$db = new DataBase();


if (isset($_POST['userid'])) 
{
    if ($db->dbConnect()) 
    {
        $db->deleteClinicianAndUser($_POST['userid']);
    }
    else echo "Error: Database connection";
} else echo "All fields are required";
?>

