<?php
require "DataBase.php";
$db = new DataBase();


if (isset($_POST['clinicianaddid'])) 
{
    if ($db->dbConnect()) 
    {
       $db->delClinicianAdmission($_POST['clinicianaddid']);
        
    } 
    else echo "Error: Database connection";
} 
else echo "All fields are required";


?>
