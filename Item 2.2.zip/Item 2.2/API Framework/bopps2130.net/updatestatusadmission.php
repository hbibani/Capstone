<?php
require "DataBase.php";
$db = new DataBase();


if (isset($_POST['admissionid']) && isset($_POST['status'])) 
{
    if ($db->dbConnect()) 
    {
        $db->updateAdmissionStatus($_POST['admissionid'], $_POST['status']);
    } 
    else echo "Error: Database connection";
} else echo "All fields are required";
?>


