<?php
require "DataBase.php";
$db = new DataBase();


if (isset($_POST['admissionid']) && isset($_POST['painscore'])  && isset($_POST['graphid'])   ) 
{
    if ($db->dbConnect()) 
    {
       $db->onPainInput($_POST['admissionid'], $_POST['graphid'], $_POST['painscore'] );
        
    } 
    else echo "Error: Database connection";
} 
else echo "All fields are required";


?>
