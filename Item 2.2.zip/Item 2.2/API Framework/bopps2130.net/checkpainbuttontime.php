<?php
require "DataBase.php";
$db = new DataBase();


if (isset($_POST['graphid']) && isset($_POST['maxtimer']) )
{
    if ($db->dbConnect())
    {
       $db->getLastValueOfPainForButton($_POST['graphid'], $_POST['maxtimer']);
    }
    else echo "Error: Database connection";
}
else echo "All fields are required";


?>
