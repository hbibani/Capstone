<?php
require "DataBase.php";
$db = new DataBase();


if (isset($_POST['searchstring'])) 
{
    if ($db->dbConnect()) 
    {
        $db->searchMedicationWild( $_POST['searchstring']);

    } 
    else echo "Error: Database connection";
} else echo "All fields are required";
?>