<?php
require "DataBase.php";
$db = new DataBase();

if (isset($_POST['medicationstayid'])) 
{
    if ($db->dbConnect()) 
    {
        $db->delMedAdmission($_POST['medicationstayid']);
    } 
} 



?>
