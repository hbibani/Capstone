<?php
require "DataBase.php";
$db = new DataBase();


if (isset($_POST['paintype']) && isset($_POST['mrn']) && isset($_POST['painregion']) && isset($_POST['datetime']) && isset($_POST['bednumber']) && isset($_POST['timer'])) 
{
    if ($db->dbConnect()) 
    {
        $db->addAdmissionClient($_POST['mrn'], $_POST['paintype'], $_POST['painregion'], $_POST['datetime'], $_POST['bednumber'], $_POST['timer']);
    } 
    else echo "Error: Database connection";
} else echo "All fields are required";
?>