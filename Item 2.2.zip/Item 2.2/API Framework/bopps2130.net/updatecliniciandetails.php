<?php
require "DataBase.php";
$db = new DataBase();


if (isset($_POST['staffnumber']) && isset($_POST['cliniciantype']) && isset($_POST['userid']) ) 
{
    if ($db->dbConnect()) 
    {
        $db->updateClinicianInfo($_POST['staffnumber'], $_POST['cliniciantype'], $_POST['userid']);
    } 
    else echo "Error: Database connection";
} else echo "All fields are required";
?>


