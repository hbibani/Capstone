<?php
require "DataBase.php";
$db = new DataBase();


if (isset($_POST['graphvalueid'])) 
{
    if ($db->dbConnect()) 
    {
        $db->deleteGraphValue($_POST['graphvalueid']);
    }
    else echo "Error: Database connection";
} else echo "All fields are required";
?>

