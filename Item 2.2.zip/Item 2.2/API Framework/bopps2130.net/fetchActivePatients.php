<?php
require "DataBase.php";
$db = new DataBase();




    if ($db->dbConnect()) 
    {
        $db->retActivePatients();
    
    } 
    else echo "Error: Database connection";



?>
