<?php
require "DataBase.php";
$db = new DataBase();


if (isset($_POST['admissionid']) && isset($_POST['q1']) && isset($_POST['q2']) && isset($_POST['q3']) && isset($_POST['q4']) ) 
{
    if ($db->dbConnect()) 
    {
        $db->modifyfeedback( $_POST['admissionid'], $_POST['q1'], $_POST['q2'], $_POST['q3'], $_POST['q4'] );

    } 
    else echo "Error: Database connection";
} else echo "All fields are required";
?>