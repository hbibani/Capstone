<?php
require "DataBase.php";
$db = new DataBase();


if (isset($_POST['medicationstayid']) && isset($_POST['medicationid']) && isset($_POST['datetime']) && isset($_POST['amount']))
{
    if ($db->dbConnect()) 
    {
        $db->modifyMedicationAdmission($_POST['medicationstayid'], $_POST['medicationid'], $_POST['datetime'], $_POST['amount']);
    } 
    else echo "Error: Database connection";
} 
else echo "All fields are required";

?>