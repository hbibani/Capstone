<?php
require "DataBase.php";
$db = new DataBase();

if ($db->dbConnect()) 
{
        $db->getMedsForList();

} 
else echo "Error: Database connection";

?>