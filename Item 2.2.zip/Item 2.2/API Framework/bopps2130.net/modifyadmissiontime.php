<?php
require "DataBase.php";
$db = new DataBase();


if (isset( $_POST['admissionid'] ) && isset( $_POST['starttime'] ) && isset( $_POST['endtime'] ) ) 
{
    if ($db->dbConnect()) 
    {
        $db->modifyAdmissionTime($_POST['admissionid'], $_POST['starttime'], $_POST['endtime']   );
    } 
    else echo "Error: Database connection";
} else echo "All fields are required";
?>
