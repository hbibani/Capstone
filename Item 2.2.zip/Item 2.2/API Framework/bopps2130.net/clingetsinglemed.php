<?php
require "DataBase.php";
$db = new DataBase();




if (isset($_POST['medicationstayid'])) 
{
    if ($db->dbConnect()) 
    {
        $stringReturn = $db->getSingleMedForPatient($_POST['medicationstayid']);
       
    }
    else echo "Error: Database connection";
    
} 
else echo "All fields are required";


?>
