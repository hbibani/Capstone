<?php
require "DataBase.php";
$db = new DataBase();


if (isset( $_POST['graphid'] ) ) 
{
    if ($db->dbConnect()) 
    {
        $db->getGraphValuesAndTime($_POST['graphid']);
    } 
    else echo "Error: Database connection";
} else echo "All fields are required";
?>

