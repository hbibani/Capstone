<?php

class DataBaseConfig
{
    public $servername;
    public $username;
    public $password;
    public $databasename;

     public function __construct()
    {
        $this->servername = 'pdb36.awardspace.net';
        $this->username = '3919211_px2130assignment';
        $this->password = 'Asus23qout#';
        $this->databasename = '3919211_px2130assignment';
    }

}

?>
