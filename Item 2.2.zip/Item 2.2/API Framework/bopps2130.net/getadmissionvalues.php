<?php
require "DataBase.php";
$db = new DataBase();


if (isset($_POST['admissionid'])) 
{
    if ($db->dbConnect()) 
    {
        $db->getAdmissionValues( $_POST['admissionid']);

    } 
    else echo "Error: Database connection";
} else echo "All fields are required";
?>