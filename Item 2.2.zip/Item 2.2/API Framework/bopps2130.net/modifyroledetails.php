<?php
require "DataBase.php";
$db = new DataBase();


if (isset($_POST['roleid']) && isset($_POST['rolename']) && isset($_POST['rolepower'])  )
{
    if ($db->dbConnect()) 
    {
        $db->modifyRole($_POST['roleid'], $_POST['rolename'], $_POST['rolepower'] );
    } 
    else echo "Error: Database connection";
} 
else echo "All fields are required";


?>
