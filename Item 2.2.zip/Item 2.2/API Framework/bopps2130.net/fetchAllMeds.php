<?php
require "DataBase.php";
$db = new DataBase();




    if ($db->dbConnect()) 
    {
        $stringReturn = $db->getMedList();
        
    } 
    else echo "Error: Database connection";



?>