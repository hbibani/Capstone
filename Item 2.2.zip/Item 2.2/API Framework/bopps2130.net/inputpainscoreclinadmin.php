<?php
require "DataBase.php";
$db = new DataBase();


if (isset($_POST['admissionid']) && isset($_POST['painscore'])  && isset($_POST['graphid'])  && isset($_POST['datetime']))
{
    if ($db->dbConnect()) 
    {
       $db->onPainInputClinAdmin($_POST['admissionid'], $_POST['graphid'], $_POST['painscore'], $_POST['datetime'] );
        
    } 
    else echo "Error: Database connection";
} 
else echo "All fields are required";


?>
