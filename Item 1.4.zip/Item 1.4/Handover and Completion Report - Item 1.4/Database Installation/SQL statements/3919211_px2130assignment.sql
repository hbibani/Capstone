-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: pdb36.awardspace.net
-- Generation Time: Oct 13, 2021 at 06:11 AM
-- Server version: 5.7.20-log
-- PHP Version: 5.5.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `3919211_px2130assignment`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `AdminID` int(11) NOT NULL,
  `UserID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `admission`
--

CREATE TABLE `admission` (
  `AdmissionID` int(11) NOT NULL,
  `PatientID` int(11) NOT NULL,
  `PainType` varchar(100) NOT NULL,
  `PainRegion` varchar(100) NOT NULL,
  `StartTime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `EndTime` datetime DEFAULT NULL,
  `Status` tinyint(1) NOT NULL,
  `Bed` varchar(30) DEFAULT NULL,
  `Concerned` int(2) DEFAULT NULL,
  `PainTimer` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admission`
--

INSERT INTO `admission` (`AdmissionID`, `PatientID`, `PainType`, `PainRegion`, `StartTime`, `EndTime`, `Status`, `Bed`, `Concerned`, `PainTimer`) VALUES
(64, 88, 'Throbbing', 'back', '2021-08-25 11:13:12', NULL, 0, '44', NULL, 0),
(65, 89, 'Throbbing.', 'Back.', '2021-08-25 11:52:18', NULL, 0, '65', 1, 0),
(66, 90, 'throbbing', 'back', '2021-08-31 10:45:39', '2021-08-31 01:00:41', 0, '24', NULL, 0),
(73, 92, 'Throbbing', 'Back', '2021-09-11 10:05:58', NULL, 0, '24', 1, 21),
(74, 93, 'Throbbing', 'Back', '2021-09-11 13:46:38', NULL, 0, '23', NULL, 15),
(76, 95, 'Throbbing', 'Back', '2021-09-14 19:56:34', '2021-09-21 11:56:06', 0, '13a', 1, 15),
(82, 101, 'Throbbing', 'Back', '2021-10-06 13:11:47', '2021-10-06 13:17:57', 0, '23', 1, 30),
(91, 118, 'Throbbing', 'Back', '2021-10-11 22:27:17', NULL, 1, '23', 0, 15),
(92, 77, 'Throbbing', 'Back', '2021-10-13 10:53:18', NULL, 1, '23', NULL, 15);

-- --------------------------------------------------------

--
-- Table structure for table `clinician`
--

CREATE TABLE `clinician` (
  `ClinicianID` int(11) NOT NULL,
  `UserID` int(11) NOT NULL,
  `StaffNumber` varchar(51) NOT NULL,
  `ClinicianType` varchar(31) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `clinician`
--

INSERT INTO `clinician` (`ClinicianID`, `UserID`, `StaffNumber`, `ClinicianType`) VALUES
(29, 146, '12345', 'Nurse'),
(32, 163, '987654321', 'Doctor'),
(40, 187, 'Test', 'Test'),
(41, 188, '0000001', 'test1'),
(49, 200, '8888888', 'test'),
(51, 206, '1234554321', 'Doctor');

-- --------------------------------------------------------

--
-- Table structure for table `clinicianadmission`
--

CREATE TABLE `clinicianadmission` (
  `ClinicianAdmissionID` int(11) NOT NULL,
  `ClinicianID` int(11) NOT NULL,
  `AdmissionID` int(11) NOT NULL,
  `PushNotification` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `clinicianadmission`
--

INSERT INTO `clinicianadmission` (`ClinicianAdmissionID`, `ClinicianID`, `AdmissionID`, `PushNotification`) VALUES
(157, 29, 91, 1);

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `FeedbackID` int(11) NOT NULL,
  `AdmissionID` int(11) NOT NULL,
  `Question1` tinyint(1) NOT NULL,
  `Question2` tinyint(1) NOT NULL,
  `Question3` tinyint(1) NOT NULL,
  `Question4` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`FeedbackID`, `AdmissionID`, `Question1`, `Question2`, `Question3`, `Question4`) VALUES
(23, 65, 1, 1, 1, 0),
(24, 64, 1, 1, 1, 1),
(25, 66, 0, 1, 1, 1),
(49, 76, 1, 1, 1, 1),
(78, 82, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `graph`
--

CREATE TABLE `graph` (
  `GraphID` int(11) NOT NULL,
  `AdmissionID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `graph`
--

INSERT INTO `graph` (`GraphID`, `AdmissionID`) VALUES
(72, 64),
(73, 65),
(74, 66),
(81, 73),
(82, 74),
(84, 76),
(90, 82),
(99, 91),
(100, 92);

-- --------------------------------------------------------

--
-- Table structure for table `graphvalue`
--

CREATE TABLE `graphvalue` (
  `GraphValueID` int(11) NOT NULL,
  `GraphID` int(11) NOT NULL,
  `PainScore` int(11) NOT NULL,
  `Time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `graphvalue`
--

INSERT INTO `graphvalue` (`GraphValueID`, `GraphID`, `PainScore`, `Time`) VALUES
(551, 90, 8, '2021-10-06 13:12:26'),
(552, 90, 9, '2021-10-06 13:40:47');

-- --------------------------------------------------------

--
-- Table structure for table `medication`
--

CREATE TABLE `medication` (
  `MedicationID` int(11) NOT NULL,
  `MedBrand` varchar(100) NOT NULL,
  `MedChemName` varchar(100) NOT NULL,
  `Dosage` varchar(100) NOT NULL,
  `DoseForm` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `medication`
--

INSERT INTO `medication` (`MedicationID`, `MedBrand`, `MedChemName`, `Dosage`, `DoseForm`) VALUES
(35, 'Cardasa', 'Aspirin', '100mg', 'Enteric Coated Oral'),
(36, 'Cartia', 'Aspirin', '100mg', 'Enteric Coated Oral');

-- --------------------------------------------------------

--
-- Table structure for table `medicationstay`
--

CREATE TABLE `medicationstay` (
  `MedicationStayID` int(11) NOT NULL,
  `MedicationID` int(11) NOT NULL,
  `AdmissionID` int(11) NOT NULL,
  `Amount` varchar(50) NOT NULL,
  `Time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `medicationstay`
--

INSERT INTO `medicationstay` (`MedicationStayID`, `MedicationID`, `AdmissionID`, `Amount`, `Time`) VALUES
(151, 35, 82, '323', '2021-10-06 13:13:52'),
(175, 35, 91, '23', '2021-10-12 12:35:53'),
(176, 35, 91, '23', '2021-10-12 12:35:53');

-- --------------------------------------------------------

--
-- Table structure for table `patient`
--

CREATE TABLE `patient` (
  `PatientID` int(11) NOT NULL,
  `UserID` int(11) NOT NULL,
  `MRN` varchar(30) NOT NULL,
  `PatientGender` varchar(11) NOT NULL,
  `PatientAge` int(11) NOT NULL,
  `PatientWeight` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `patient`
--

INSERT INTO `patient` (`PatientID`, `UserID`, `MRN`, `PatientGender`, `PatientAge`, `PatientWeight`) VALUES
(77, 148, '12345', 'Male', 25, 33),
(81, 154, '98765', 'Male', 24, 24),
(83, 156, '876876', 'Female', 14, 123),
(84, 157, '987654321', 'Male', 24, 255),
(87, 160, '123456789', 'Male', 25, 25),
(88, 161, '543216', 'Male', 232, 32),
(89, 162, '654321', 'Male', 23, 42),
(90, 165, '1234567891', 'Male', 32, 323),
(91, 166, '43532', 'Male', 25, 44),
(92, 167, '555553', 'Male', 24, 233),
(93, 168, '77777', 'Male', 25, 32),
(94, 169, '98769876', 'Male', 33, 232),
(95, 171, '12345678', 'Male', 24, 25),
(96, 172, '098665', 'Male', 25, 233),
(98, 174, '76543578', 'Male', 23, 23),
(99, 175, '8974342', 'Male', 23, 23),
(100, 176, '7654321', 'Female', 233, 233),
(101, 183, '987987987', 'Male', 23, 23),
(105, 193, '1234566', 'Male', 23, 23),
(113, 208, '0909090909', 'Male', 12, 23),
(117, 214, '11398229', 'Male', 23, 23),
(118, 215, '9999999', 'Male', 23, 12);

-- --------------------------------------------------------

--
-- Table structure for table `patientnotes`
--

CREATE TABLE `patientnotes` (
  `PatientNotesID` int(11) NOT NULL,
  `AdmissionID` int(11) NOT NULL,
  `Notes` varchar(500) NOT NULL,
  `Time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `patientnotes`
--

INSERT INTO `patientnotes` (`PatientNotesID`, `AdmissionID`, `Notes`, `Time`) VALUES
(60, 82, 'Heja is testing the product.', '2021-10-06 13:15:26'),
(61, 82, 'Heja is testing the product.', '2021-10-06 13:15:26'),
(62, 82, 'Heja is testing the product.', '2021-10-06 13:15:26'),
(63, 82, 'Heja is testing the product.', '2021-10-06 13:15:26');

-- --------------------------------------------------------

--
-- Table structure for table `role`
--

CREATE TABLE `role` (
  `RoleID` int(11) NOT NULL,
  `RoleName` varchar(20) NOT NULL,
  `RolePower` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `role`
--

INSERT INTO `role` (`RoleID`, `RoleName`, `RolePower`) VALUES
(1, 'Admin', 1),
(2, 'Clinician', 2),
(3, 'Patient', 3);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `UserID` int(11) NOT NULL,
  `RoleID` int(11) NOT NULL,
  `Username` varchar(51) NOT NULL,
  `Password` varchar(51) NOT NULL,
  `Token` varchar(500) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`UserID`, `RoleID`, `Username`, `Password`, `Token`) VALUES
(26, 1, 'admin', 'admin', 'c7JkhQrbRWqgrUcnQgTywB:APA91bGSabM4OT2eyhruFZ4L1W2Wf1fsRjnruvMSWLoTfWkezg7jpkYt5-ewv4znrEJZWunhu49Dkut8Orb0law4Co8mSpiKZHbVKveGpeDPsYP8SKV8MeVzH1sKuG4uqDxtkzLj4cAG'),
(146, 2, 'clinician', 'password', 'dVpcctK8STS_wpJvyOF0a0:APA91bFnTuqRfAA9XfC18tAzVnBlVClKBlRHXhvSoVp1M7CR1r77TQ4YwtVBO9bqUplZOyb0cdntWJCDgsHlML0eF8PUmUqyKL0fG-1lYVznWpU7qFqS11BU1_4aelLZiEmP62GdHBBc'),
(148, 3, 'patient1', 'patient1', 'dVpcctK8STS_wpJvyOF0a0:APA91bFnTuqRfAA9XfC18tAzVnBlVClKBlRHXhvSoVp1M7CR1r77TQ4YwtVBO9bqUplZOyb0cdntWJCDgsHlML0eF8PUmUqyKL0fG-1lYVznWpU7qFqS11BU1_4aelLZiEmP62GdHBBc'),
(154, 3, 'patient2', 'password', NULL),
(156, 3, 'username2312', 'password', NULL),
(157, 3, 'testuser', 'password', NULL),
(160, 3, 'patient3', 'patient3', 'c7JkhQrbRWqgrUcnQgTywB:APA91bGSabM4OT2eyhruFZ4L1W2Wf1fsRjnruvMSWLoTfWkezg7jpkYt5-ewv4znrEJZWunhu49Dkut8Orb0law4Co8mSpiKZHbVKveGpeDPsYP8SKV8MeVzH1sKuG4uqDxtkzLj4cAG'),
(161, 3, 'username2321', 'password1', NULL),
(162, 3, 'patient6', 'patient6', 'c7JkhQrbRWqgrUcnQgTywB:APA91bGSabM4OT2eyhruFZ4L1W2Wf1fsRjnruvMSWLoTfWkezg7jpkYt5-ewv4znrEJZWunhu49Dkut8Orb0law4Co8mSpiKZHbVKveGpeDPsYP8SKV8MeVzH1sKuG4uqDxtkzLj4cAG'),
(163, 2, 'clinician2', 'password', NULL),
(165, 3, 'patient10', 'password', NULL),
(166, 3, 'username23', 'password', NULL),
(167, 3, 'username55553', 'password', NULL),
(168, 3, 'username7777', 'password', NULL),
(169, 3, 'userrname9876', 'password', NULL),
(170, 3, '', '', NULL),
(171, 3, 'username10', 'password', NULL),
(172, 3, 'username09', 'password', NULL),
(174, 3, 'username765', 'password', NULL),
(175, 3, 'username782', 'password', NULL),
(176, 3, 'username7657711', 'password76511', NULL),
(183, 3, 'username987', 'password', NULL),
(187, 2, 'testtesttest', 'password', NULL),
(188, 2, 'testesttestest1', 'testesttest1', NULL),
(193, 3, 'patientpatient', 'password', 'c7JkhQrbRWqgrUcnQgTywB:APA91bGSabM4OT2eyhruFZ4L1W2Wf1fsRjnruvMSWLoTfWkezg7jpkYt5-ewv4znrEJZWunhu49Dkut8Orb0law4Co8mSpiKZHbVKveGpeDPsYP8SKV8MeVzH1sKuG4uqDxtkzLj4cAG'),
(200, 2, 'testtesttesttesttest', 'testtest', NULL),
(206, 2, 'username12345654321', 'password', NULL),
(208, 3, 'username0909', 'password', 'c7JkhQrbRWqgrUcnQgTywB:APA91bGSabM4OT2eyhruFZ4L1W2Wf1fsRjnruvMSWLoTfWkezg7jpkYt5-ewv4znrEJZWunhu49Dkut8Orb0law4Co8mSpiKZHbVKveGpeDPsYP8SKV8MeVzH1sKuG4uqDxtkzLj4cAG'),
(214, 3, 'username229', 'password red', NULL),
(215, 3, 'username9999', 'password', 'c7JkhQrbRWqgrUcnQgTywB:APA91bGSabM4OT2eyhruFZ4L1W2Wf1fsRjnruvMSWLoTfWkezg7jpkYt5-ewv4znrEJZWunhu49Dkut8Orb0law4Co8mSpiKZHbVKveGpeDPsYP8SKV8MeVzH1sKuG4uqDxtkzLj4cAG');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`AdminID`),
  ADD KEY `fk_to_userid` (`UserID`);

--
-- Indexes for table `admission`
--
ALTER TABLE `admission`
  ADD PRIMARY KEY (`AdmissionID`),
  ADD KEY `fk_to_patientIDadd` (`PatientID`);

--
-- Indexes for table `clinician`
--
ALTER TABLE `clinician`
  ADD PRIMARY KEY (`ClinicianID`),
  ADD UNIQUE KEY `fk_to_useridclin` (`UserID`) USING BTREE,
  ADD UNIQUE KEY `StaffNumber` (`StaffNumber`);

--
-- Indexes for table `clinicianadmission`
--
ALTER TABLE `clinicianadmission`
  ADD PRIMARY KEY (`ClinicianAdmissionID`),
  ADD KEY `fk_to_admissionIDca` (`AdmissionID`),
  ADD KEY `ClinicianID` (`ClinicianID`) USING BTREE;

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`FeedbackID`),
  ADD UNIQUE KEY `AdmissionID` (`AdmissionID`);

--
-- Indexes for table `graph`
--
ALTER TABLE `graph`
  ADD PRIMARY KEY (`GraphID`),
  ADD UNIQUE KEY `AdmissionID` (`AdmissionID`) USING BTREE;

--
-- Indexes for table `graphvalue`
--
ALTER TABLE `graphvalue`
  ADD PRIMARY KEY (`GraphValueID`),
  ADD KEY `fk_to_graphid` (`GraphID`);

--
-- Indexes for table `medication`
--
ALTER TABLE `medication`
  ADD PRIMARY KEY (`MedicationID`);

--
-- Indexes for table `medicationstay`
--
ALTER TABLE `medicationstay`
  ADD PRIMARY KEY (`MedicationStayID`),
  ADD KEY `fk_to_admissionIDms` (`AdmissionID`),
  ADD KEY `fk_to_medicationIDms` (`MedicationID`);

--
-- Indexes for table `patient`
--
ALTER TABLE `patient`
  ADD PRIMARY KEY (`PatientID`),
  ADD UNIQUE KEY `MRN` (`MRN`),
  ADD KEY `fk_to_useridpati` (`UserID`);

--
-- Indexes for table `patientnotes`
--
ALTER TABLE `patientnotes`
  ADD PRIMARY KEY (`PatientNotesID`),
  ADD KEY `AdmissionID` (`AdmissionID`) USING BTREE;

--
-- Indexes for table `role`
--
ALTER TABLE `role`
  ADD PRIMARY KEY (`RoleID`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`UserID`),
  ADD UNIQUE KEY `Username` (`Username`),
  ADD KEY `fk_to_Roleid` (`RoleID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `AdminID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `admission`
--
ALTER TABLE `admission`
  MODIFY `AdmissionID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=93;
--
-- AUTO_INCREMENT for table `clinician`
--
ALTER TABLE `clinician`
  MODIFY `ClinicianID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;
--
-- AUTO_INCREMENT for table `clinicianadmission`
--
ALTER TABLE `clinicianadmission`
  MODIFY `ClinicianAdmissionID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=158;
--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `FeedbackID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=99;
--
-- AUTO_INCREMENT for table `graph`
--
ALTER TABLE `graph`
  MODIFY `GraphID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=101;
--
-- AUTO_INCREMENT for table `graphvalue`
--
ALTER TABLE `graphvalue`
  MODIFY `GraphValueID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=614;
--
-- AUTO_INCREMENT for table `medication`
--
ALTER TABLE `medication`
  MODIFY `MedicationID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;
--
-- AUTO_INCREMENT for table `medicationstay`
--
ALTER TABLE `medicationstay`
  MODIFY `MedicationStayID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=177;
--
-- AUTO_INCREMENT for table `patient`
--
ALTER TABLE `patient`
  MODIFY `PatientID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=119;
--
-- AUTO_INCREMENT for table `patientnotes`
--
ALTER TABLE `patientnotes`
  MODIFY `PatientNotesID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=95;
--
-- AUTO_INCREMENT for table `role`
--
ALTER TABLE `role`
  MODIFY `RoleID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `UserID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=216;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `admin`
--
ALTER TABLE `admin`
  ADD CONSTRAINT `admin_ibfk_1` FOREIGN KEY (`UserID`) REFERENCES `user` (`UserID`);

--
-- Constraints for table `admission`
--
ALTER TABLE `admission`
  ADD CONSTRAINT `admission_ibfk_1` FOREIGN KEY (`PatientID`) REFERENCES `patient` (`PatientID`);

--
-- Constraints for table `clinician`
--
ALTER TABLE `clinician`
  ADD CONSTRAINT `clinician_ibfk_1` FOREIGN KEY (`UserID`) REFERENCES `user` (`UserID`);

--
-- Constraints for table `clinicianadmission`
--
ALTER TABLE `clinicianadmission`
  ADD CONSTRAINT `clinicianadmission_ibfk_1` FOREIGN KEY (`AdmissionID`) REFERENCES `admission` (`AdmissionID`),
  ADD CONSTRAINT `clinicianadmission_ibfk_2` FOREIGN KEY (`ClinicianID`) REFERENCES `clinician` (`ClinicianID`);

--
-- Constraints for table `feedback`
--
ALTER TABLE `feedback`
  ADD CONSTRAINT `feedback_ibfk_1` FOREIGN KEY (`AdmissionID`) REFERENCES `admission` (`AdmissionID`);

--
-- Constraints for table `graph`
--
ALTER TABLE `graph`
  ADD CONSTRAINT `graph_ibfk_1` FOREIGN KEY (`AdmissionID`) REFERENCES `admission` (`AdmissionID`);

--
-- Constraints for table `graphvalue`
--
ALTER TABLE `graphvalue`
  ADD CONSTRAINT `graphvalue_ibfk_1` FOREIGN KEY (`GraphID`) REFERENCES `graph` (`GraphID`);

--
-- Constraints for table `medicationstay`
--
ALTER TABLE `medicationstay`
  ADD CONSTRAINT `medicationstay_ibfk_1` FOREIGN KEY (`AdmissionID`) REFERENCES `admission` (`AdmissionID`),
  ADD CONSTRAINT `medicationstay_ibfk_2` FOREIGN KEY (`MedicationID`) REFERENCES `medication` (`MedicationID`);

--
-- Constraints for table `patient`
--
ALTER TABLE `patient`
  ADD CONSTRAINT `fk_to_useridpati` FOREIGN KEY (`UserID`) REFERENCES `user` (`UserID`);

--
-- Constraints for table `patientnotes`
--
ALTER TABLE `patientnotes`
  ADD CONSTRAINT `patientnotes_ibfk_1` FOREIGN KEY (`AdmissionID`) REFERENCES `admission` (`AdmissionID`);

--
-- Constraints for table `user`
--
ALTER TABLE `user`
  ADD CONSTRAINT `user_ibfk_1` FOREIGN KEY (`RoleID`) REFERENCES `role` (`RoleID`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
